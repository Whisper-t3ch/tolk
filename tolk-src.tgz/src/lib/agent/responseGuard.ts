// ============================================================
// Барьер безопасности для финального текстового ответа ассистента
// психологу — последняя проверка ПЕРЕД сохранением/показом, а не
// замена промпт-инструкций. Правила в AGENT_SYSTEM_PROMPT ("НИКОГДА
// не упоминай психологу технические имена инструментов") и фикс
// UUID-утечки — это первая линия защиты, полагающаяся на то, что
// модель СЛЕДУЕТ инструкциям. Но 19.09 обнаружено (на Pro 5.1, при
// оценке перехода с Pro 5 — см. yandexgpt.ts): иногда модель вместо
// заполнения структурированного поля toolCallList.toolCalls пишет
// текстовое подобие вызова инструмента прямо в ответ психологу
// ("```search_knowledge_base\n{\"query\":...}```"). Это происходит
// на уровне API-поведения модели, а не на уровне текста промпта —
// никакая формулировка инструкции не гарантирует, что степень
// "послушности" будет 100% для любой модели в любой момент.
//
// Поэтому этот файл — не специфичный парсер под сегодняшний паттерн
// Pro 5.1 (та решена откатом на Pro 5, см. git revert 334a189), а
// общий защитный слой: если ответ ЛЮБОЙ модели (включая уже
// используемую Pro 5, которая тоже не застрахована от подобных
// сбоев — см. UUID-баг того же дня) содержит признаки утечки
// технической информации, психолог никогда не увидит "сырой" ответ.
//
// Стратегия при срабатывании — fallback-текст, БЕЗ повторного вызова
// LLM: это не увеличивает стоимость и задержку запроса (в отличие от
// варианта "попроси модель переформулировать"), и это та же идея,
// что уже применена в системном промпте для UUID-случая: честно
// признаться психологу, что ответ не сформировался, и предложить
// переформулировать/уточнить — вместо того чтобы показать сломанный
// текст или тратить второй LLM-вызов на попытку исправления.
// ============================================================

const FALLBACK_MESSAGE =
  "Не удалось сформировать ответ на этот вопрос. Пожалуйста, переформулируйте его или уточните, что именно нужно — и я отвечу отдельным сообщением.";

// Имена наших инструментов — используются как основа для двух разных
// проверок ниже (точное совпадение имени и общий snake_case паттерн).
// Список должен обновляться вместе с AGENT_TOOLS (tools.ts), но даже
// при рассинхроне общий snake_case паттерн ниже перехватывает новые
// имена инструментов автоматически.
const KNOWN_TOOL_NAMES = [
  "search_knowledge_base",
  "find_client_by_name",
  "get_period_summary",
  "find_available_slots",
  "create_session",
  "send_message_to_client",
  "reschedule_session",
  "cancel_session",
  "get_client_tests",
  "get_client_homework",
  "assign_homework",
  "get_session_transcript",
  "get_client_sessions",
  "update_client_notes",
  "get_upcoming_sessions",
  "get_client_profile",
  "list_clients",
  "get_soap_notes",
];

// UUID v4-подобная строка (де-факто формат Supabase/Postgres uuid) —
// та же проверка, что уже была найдена нужной в UUID-баге того же дня,
// продублирована здесь как структурный, а не только промпт-барьер.
const UUID_PATTERN = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i;

// Явный вызов инструмента, напечатанный как текст: имя_функции с
// открывающей скобкой/JSON сразу после (в разных вариантах — с
// markdown-код-блоком или без). Не ловит обычное упоминание похожих
// слов в естественном тексте, т.к. требует характерного "имя(" или
// "имя\n{" паттерна сразу после известного имени инструмента.
function containsPseudoToolCall(text: string): boolean {
  for (const name of KNOWN_TOOL_NAMES) {
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`\\b${escaped}\\b\\s*[({\\n]`, "i");
    if (pattern.test(text)) return true;
  }
  return false;
}

// Общий snake_case паттерн длиной от 2 слов, похожий на имя функции/
// поля БД, встреченный рядом с открывающей скобкой или JSON — ловит
// НЕ перечисленные явно в KNOWN_TOOL_NAMES случаи (новые инструменты,
// названия полей вида client_id, source_type), не давая расширять
// список вручную при каждом изменении tools.ts.
const GENERIC_TECHNICAL_PATTERN = /\b[a-z][a-z0-9]*(?:_[a-z0-9]+){1,4}\b\s*[({]/;

const UUID_GLOBAL = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;

/** Убирает UUID вместе с обрамлением («(id: …)», «ID: …», «[…]») и подчищает пробелы/пунктуацию. */
export function stripUuids(text: string): string {
  return text
    .replace(new RegExp(String.raw`\s*[(\[]\s*(?:id|ID|Id|идентификатор|session_id|client_id)?\s*[:=]?\s*${UUID_GLOBAL.source}\s*[)\]]`, "gi"), "")
    .replace(new RegExp(String.raw`\s*(?:\bid|\bID|идентификатор(?:ом)?|session_id|client_id)\s*[:=]?\s*${UUID_GLOBAL.source}`, "gi"), "")
    .replace(UUID_GLOBAL, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/ +([,.;:!?])/g, "$1")
    .replace(/\(\s*\)/g, "")
    .trim();
}

export interface ResponseGuardResult {
  safe: boolean;
  reason?: "uuid" | "pseudo_tool_call" | "generic_technical_pattern";
}

/**
 * Проверяет финальный текстовый ответ ассистента на признаки утечки
 * технической информации психологу. НЕ вызывается для tool call —
 * только для текста, который реально попадёт в чат психолога.
 */
export function checkResponseSafety(text: string): ResponseGuardResult {
  if (UUID_PATTERN.test(text)) {
    return { safe: false, reason: "uuid" };
  }
  if (containsPseudoToolCall(text)) {
    return { safe: false, reason: "pseudo_tool_call" };
  }
  if (GENERIC_TECHNICAL_PATTERN.test(text)) {
    return { safe: false, reason: "generic_technical_pattern" };
  }
  return { safe: true };
}

/**
 * Возвращает безопасный для показа психологу текст: исходный текст,
 * если он прошёл проверку, иначе fallback без утечки. Логирует
 * срабатывание — это должно быть редким событием, стоит отслеживать
 * частоту в проде отдельно от обычных ошибок.
 */
export function guardResponseText(text: string): string {
  const result = checkResponseSafety(text);
  if (result.safe) return text;
  // Голый идентификатор в тексте (id клиента/сессии из результата инструмента) не повод выбрасывать весь
  // ответ: на GigaChat это срабатывало на каждом втором вопросе про клиента. Убираем идентификаторы и
  // показываем остальное, если текст после очистки безопасен и осмысленен.
  if (result.reason === "uuid") {
    const cleaned = stripUuids(text);
    if (cleaned.length >= 20 && checkResponseSafety(cleaned).safe) {
      console.warn("responseGuard: идентификаторы удалены из ответа", JSON.stringify({ reason: "uuid_stripped" }));
      return cleaned;
    }
  }
  console.error("responseGuard: заблокирован небезопасный ответ", JSON.stringify({ reason: result.reason }));
  return FALLBACK_MESSAGE;
}
