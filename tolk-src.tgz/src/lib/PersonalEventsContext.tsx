"use client";
import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { createClient } from "@/lib/supabase/client";

// ------------------------------------------------------------
// Личные дела в календаре (не сессии с клиентами) — например "Зал",
// "Обед", "Врач". Пока не хранятся в Supabase (это отдельная предметная
// область, ещё не спроектирована как таблица — см. lib/data/sessions.ts
// для сравнения с тем, как устроены реальные сессии). Чтобы психолог
// не терял добавленные события при перезагрузке страницы, состояние
// сохраняется в localStorage браузера — этого достаточно для демо и
// личного использования одним пользователем с одного устройства.
// ------------------------------------------------------------
export interface PersonalEvent {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  title: string;
}

interface PersonalEventsContextType {
  events: PersonalEvent[];
  addEvent: (event: Omit<PersonalEvent, "id">) => void;
  removeEvent: (id: string) => void;
  updateEventTime: (id: string, time: string) => void;
}

// Ключ хранения привязан к id психолога. Раньше он был общий на весь
// домен ("tolk_personal_events_v4"), поэтому личные дела не принадлежали
// никому конкретно: психолог, вошедший следующим на том же компьютере,
// видел в своём календаре чужие «Йогу» и «Врача» — включая полностью
// пустой кабинет нового пользователя.
const STORAGE_PREFIX = "tolk_personal_events_v5";

function storageKeyFor(psychologistId: string | null): string {
  return psychologistId ? `${STORAGE_PREFIX}:${psychologistId}` : STORAGE_PREFIX;
}

// Старые общие ключи подчищаем, чтобы события прошлых версий не всплывали
// у следующего вошедшего пользователя.
const LEGACY_KEYS = ["tolk_personal_events_v4", "tolk_personal_events_seeded_v4"];

const PersonalEventsContext = createContext<PersonalEventsContextType | undefined>(undefined);

function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// Плотное демо-расписание для показа на созвоне — генерируется один раз
// при первом заходе (если в localStorage ещё ничего нет), дальше психолог
// может добавлять/удалять/двигать события сам и они не будут перезатираться.
const DAILY_TEMPLATES: Array<Array<{ time: string; title: string }>> = [
  [
    { time: "07:00", title: "Йога" },
    { time: "08:00", title: "Завтрак" },
    { time: "13:00", title: "Обед" },
    { time: "18:30", title: "Прогулка в парке" },
  ],
  [
    { time: "07:30", title: "Зал" },
    { time: "08:30", title: "Завтрак" },
    { time: "13:00", title: "Обед" },
    { time: "19:00", title: "Ужин с семьёй" },
  ],
  [
    { time: "07:00", title: "Медитация" },
    { time: "08:00", title: "Завтрак" },
    { time: "12:30", title: "Обед" },
    { time: "17:00", title: "Супервизия" },
  ],
  [
    { time: "07:30", title: "Пробежка" },
    { time: "08:30", title: "Завтрак" },
    { time: "13:00", title: "Обед" },
    { time: "18:00", title: "Прогулка с ребёнком" },
  ],
  [
    { time: "07:00", title: "Йога" },
    { time: "08:00", title: "Завтрак" },
    { time: "13:00", title: "Обед" },
    { time: "20:00", title: "Кино с женой" },
  ],
  [
    { time: "09:00", title: "Врач" },
    { time: "10:00", title: "Завтрак поздний" },
    { time: "14:00", title: "Обед" },
  ],
  [
    { time: "10:00", title: "Завтрак" },
    { time: "12:00", title: "Время с семьёй" },
    { time: "19:00", title: "Настольные игры" },
  ],
];
// Бытовые события теперь на каждый день без исключений — чтобы дни с
// сессиями клиентов не оставались "голыми" (раньше некоторые дни недели
// пропускались, из-за чего в дне с сессиями иногда не было ни одного
// бытового события и календарь выглядел неровно).
// Диапазон генерации — с 1 числа текущего месяца (а не "-3 дня от сегодня")
// до конца следующего месяца, чтобы весь текущий месяц был заполнен
// целиком при пролистывании назад, а не обрывался на дне запуска сида.
// ПРИМЕЧАНИЕ: сид генерируется независимо от реальных сессий из Supabase
// (они подгружаются асинхронно в SessionContext), поэтому теоретическое
// наложение бытового события и сессии клиента на одно время здесь не
// проверяется — это не страшно для демо-данных. Автосдвиг на свободный
// слот (см. lib/calendarSlots.ts) работает только при добавлении/
// редактировании события через интерфейс.
function buildSeedEvents(): PersonalEvent[] {
  const today = new Date();
  const rangeStart = new Date(today.getFullYear(), today.getMonth(), 1);
  const rangeEnd = new Date(today.getFullYear(), today.getMonth() + 2, 0); // конец следующего месяца
  const totalDays = Math.round((rangeEnd.getTime() - rangeStart.getTime()) / 86400000);

  const events: PersonalEvent[] = [];
  for (let offset = 0; offset <= totalDays; offset++) {
    const template = DAILY_TEMPLATES[offset % DAILY_TEMPLATES.length];
    const d = new Date(rangeStart.getFullYear(), rangeStart.getMonth(), rangeStart.getDate() + offset);
    template.forEach((evt, i) => {
      events.push({ id: `seed-${offset}-${i}`, date: toDateStr(d), time: evt.time, title: evt.title });
    });
  }
  return events;
}

function loadFromStorage(psychologistId: string | null): PersonalEvent[] {
  if (typeof window === "undefined") return [];
  try {
    // Календарь не засеивается демо-распорядком (Йога / Завтрак / Обед /
    // Врач): для психолога это чужие выдуманные события, которые он не
    // создавал. Начинаем с пустого календаря — события добавляет он сам.
    // buildSeedEvents() оставлена для демонстрационных показов.
    for (const legacy of LEGACY_KEYS) window.localStorage.removeItem(legacy);

    const raw = window.localStorage.getItem(storageKeyFor(psychologistId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function PersonalEventsProvider({ children }: { children: ReactNode }) {
  const [events, setEvents] = useState<PersonalEvent[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [psychologistId, setPsychologistId] = useState<string | null>(null);

  // Узнаём, чей это кабинет: события хранятся отдельно для каждого
  // психолога, иначе следующий вошедший на том же компьютере увидит
  // чужой календарь.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let id: string | null = null;
      try {
        const supabase = createClient();
        const { data } = await supabase.auth.getUser();
        id = data.user?.id ?? null;
      } catch {
        id = null;
      }
      if (cancelled) return;
      setPsychologistId(id);
      setEvents(loadFromStorage(id));
      setHydrated(true);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!hydrated) return; // не перезаписываем storage пустым массивом до первой загрузки
    try {
      window.localStorage.setItem(storageKeyFor(psychologistId), JSON.stringify(events));
    } catch {
      // localStorage может быть недоступен (приватный режим и т.п.) — не критично.
    }
  }, [events, hydrated, psychologistId]);

  const addEvent = useCallback((event: Omit<PersonalEvent, "id">) => {
    setEvents(prev => [...prev, { ...event, id: `pe-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` }]);
  }, []);

  const removeEvent = useCallback((id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  }, []);

  const updateEventTime = useCallback((id: string, time: string) => {
    setEvents(prev => prev.map(e => (e.id === id ? { ...e, time } : e)));
  }, []);

  return (
    <PersonalEventsContext.Provider value={{ events, addEvent, removeEvent, updateEventTime }}>
      {children}
    </PersonalEventsContext.Provider>
  );
}

export function usePersonalEvents() {
  const context = useContext(PersonalEventsContext);
  if (context === undefined) {
    throw new Error("usePersonalEvents must be used within PersonalEventsProvider");
  }
  return context;
}
