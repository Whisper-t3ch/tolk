"use client";
import { use, useState, useRef, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Send, ChevronLeft, Download,
  TrendingUp, TrendingDown, Minus, ArrowRight, Video, Clock,
  Sparkles, X, Link2, Copy, Check, Paperclip, BookOpen, Search,
} from "lucide-react";
import { demoClientExtrasByName } from "@/lib/demo-client-extras";
import { APPROACH_LABELS, type Approach } from "@/lib/approaches";
import { TEST_SCALES, type TestType } from "@/lib/testScales";
import { useSession } from "@/lib/SessionContext";
import { useClients } from "@/lib/ClientsContext";
import { useProfile } from "@/lib/ProfileContext";
import { updateClientRecord, softDeleteClient } from "@/lib/data/clients";
import { formatDateInTimeZone, formatTimeInTimeZone, todayInTimeZone, isSessionPast, DEFAULT_TIMEZONE } from "@/lib/timezone";
import { Button, Card, CardContent } from "@/components/ui";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// Возраст со склонением: «21 год», «34 года», «29 лет». Раньше всегда
// подставлялось «лет», а у клиента без возраста под именем оставалось
// висячее «лет ·» вообще без числа.
function formatAge(age: number): string {
  const mod100 = age % 100;
  const mod10 = age % 10;
  if (mod100 >= 11 && mod100 <= 14) return `${age} лет`;
  if (mod10 === 1) return `${age} год`;
  if (mod10 >= 2 && mod10 <= 4) return `${age} года`;
  return `${age} лет`;
}

// Дата сессии для списков в карточке клиента: «21 сентября», с годом —
// только если год не текущий. Раньше выводилась сырая строка из БД
// («2026-09-21 · 16:00»), хотя на /sessions и в календаре тот же самый
// день уже показывался по-человечески.
function formatSessionDate(date: string): string {
  const [y, m, d] = date.split("-").map(Number);
  if (!y || !m || !d) return date;
  const label = new Date(Date.UTC(y, m - 1, d)).toLocaleDateString("ru", {
    day: "numeric",
    month: "long",
    timeZone: "UTC",
  });
  return y === new Date().getFullYear() ? label : `${label} ${y}`;
}

const EMPTY_TRIGGERS: string[] = [];
const EMPTY_PROGRESS = { aiScore: 0, psychologistScore: null, clientScore: null, history: [] as Array<{ date: string; aiScore: number; psychologistScore?: number; clientScore?: number }> };

const avatarColors = ["#2D6A5C", "#157347", "#B45309", "#B91C1C", "#6D28D9"];

interface ChatMessage {
  id: string;
  role: "client" | "psychologist";
  text: string;
  time: string;
  file?: { name: string; size: string };
  status?: "pending" | "sent" | "delivered" | "failed";
  errorMessage?: string | null;
}

// Материал из базы знаний (/api/knowledge), доступный для вставки в
// сообщение клиенту прямо из чата — то же, что вкладки "Техники" /
// "Материалы" в разделе База знаний, просто отфильтрованное подмножество
// полей, нужных только для выбора и вставки текста.
interface KnowledgeAttachItem {
  id: string;
  title: string | null;
  content: string;
  source_type: string;
}

// Короткие ярлыки типов материала для пикера вложений — те же подписи,
// что в разделе База знаний, продублированы здесь, чтобы не тащить
// зависимость между независимыми страницами ради одной константы.
const ATTACH_SOURCE_TYPE_LABELS: Record<string, string> = {
  technique: "Техника",
  homework: "ДЗ",
  article: "Материал",
  manual: "Материал",
  protocol: "Протокол",
  test: "Тест",
};

interface MessengerLink {
  platform: "telegram" | "vk";
  external_username: string | null;
  linked_at: string;
}

interface TestResult {
  id: string;
  // Не TestType: там лежат только пять старых клинических шкал, а в
  // test_type реально приходит ключ любой из 22 методик справочника
  // (PRIKHOZHAN, ZUNG, TAS26 и т.д.).
  test_type: string;
  score: number;
  max_score: number;
  interpretation: string | null;
  status: "pending" | "completed";
  created_at: string;
  // Название методики из test_questionnaires — источник подписи для
  // методик, которых нет в TEST_SCALES.
  title?: string | null;
}

// Отправленное клиенту домашнее задание. Хранится как сообщение с
// kind='homework' (см. sendHomework в agent/executor.ts), отдельной
// таблицы под ДЗ нет.
interface HomeworkItem {
  id: string;
  text: string;
  status: string;
  created_at: string;
}

// Человекочитаемое название методики: сначала то, что пришло из
// справочника, затем подпись старой клинической шкалы, и в крайнем
// случае — сам ключ. Раньше здесь было прямое обращение
// TEST_SCALES[test_type].label, и карточка клиента падала целиком,
// стоило клиенту пройти любую методику вне старой пятёрки.
function testDisplayName(test: { test_type: string; title?: string | null }): string {
  if (test.title) return test.title;
  const scale = TEST_SCALES[test.test_type as TestType];
  return scale?.label ?? test.test_type;
}

// Приводит запись из таблицы messages (API-формат) к формату чата на экране.
function toChatMessage(raw: {
  id: string; direction: string; text: string; created_at: string;
  status: string; error_message: string | null;
}, timeZone: string): ChatMessage {
  const time = formatTimeInTimeZone(new Date(raw.created_at), timeZone);
  return {
    id: raw.id,
    role: raw.direction === "incoming" ? "client" : "psychologist",
    text: raw.text,
    time,
    status: raw.status as ChatMessage["status"],
    errorMessage: raw.error_message,
  };
}

const TABS = [
  { id: "sessions", label: "Сессии" },
  { id: "summary", label: "Сводка" },
  { id: "analytics", label: "Аналитика" },
] as const;

type TabId = typeof TABS[number]["id"];

export default function ClientProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { clients, loading: clientsLoading, refresh: refreshClients } = useClients();
  const client = clients.find(c => c.id === id);
  const { sessions, addSession } = useSession();
  const { profile } = useProfile();
  const timeZone = profile?.timezone ?? DEFAULT_TIMEZONE;
  const router = useRouter();
  const [startingSession, setStartingSession] = useState(false);

  // Раньше карточку клиента нельзя было отредактировать или архивировать
  // никак — ни опечатку в имени поправить, ни завершить работу с
  // клиентом. Фильтры "На паузе"/"Завершено" на /clients при этом есть,
  // но выставить эти статусы было неоткуда — фильтры были заведомо
  // пустыми. updateClientRecord/softDeleteClient уже существовали на
  // уровне data-слоя, не хватало только UI.
  const [showEditClient, setShowEditClient] = useState(false);
  const [editName, setEditName] = useState("");
  const [editAge, setEditAge] = useState("");
  const [editGender, setEditGender] = useState<"male" | "female">("female");
  const [editRequest, setEditRequest] = useState("");
  const [editApproach, setEditApproach] = useState("");
  const [editStatus, setEditStatus] = useState<"active" | "pause" | "completed">("active");
  const [savingClient, setSavingClient] = useState(false);
  const [editClientError, setEditClientError] = useState<string | null>(null);
  const [showDeleteClientConfirm, setShowDeleteClientConfirm] = useState(false);
  const [deletingClient, setDeletingClient] = useState(false);
  const [deleteClientError, setDeleteClientError] = useState<string | null>(null);

  function openEditClient() {
    if (!client) return;
    setEditName(client.name);
    setEditAge(client.age != null ? String(client.age) : "");
    setEditGender(client.gender ?? "female");
    setEditRequest(client.request);
    setEditApproach(client.approach);
    setEditStatus(client.status);
    setEditClientError(null);
    setShowEditClient(true);
  }

  async function saveClientEdits() {
    if (!client || savingClient) return;
    if (!editName.trim()) {
      setEditClientError("Укажите имя");
      return;
    }
    setSavingClient(true);
    setEditClientError(null);
    try {
      await updateClientRecord(client.id, {
        name: editName.trim(),
        age: editAge.trim() ? Number(editAge) : null,
        gender: editGender,
        request: editRequest.trim(),
        approach: editApproach.trim(),
        status: editStatus,
      });
      await refreshClients();
      setShowEditClient(false);
    } catch (e) {
      setEditClientError(e instanceof Error ? e.message : "Не удалось сохранить изменения");
    } finally {
      setSavingClient(false);
    }
  }

  async function confirmDeleteClient() {
    if (!client || deletingClient) return;
    setDeletingClient(true);
    // Ошибку обязательно показываем: пустой catch здесь уже приводил к
    // тому, что удаление молча не работало (RLS отклоняла запись
    // deleted_at, см. migration_027), а психолог видел только то, что
    // после нажатия «Удалить» ничего не происходит.
    setDeleteClientError(null);
    try {
      await softDeleteClient(client.id);
      await refreshClients();
      router.push("/clients");
    } catch (e) {
      setDeleteClientError(e instanceof Error ? e.message : "Не удалось удалить клиента");
      setDeletingClient(false);
    }
  }

  // "Начать сессию" на карточке клиента — спонтанный звонок вне
  // расписания (в отличие от запланированной сессии из /sessions).
  // Создаём запись sessions "на сейчас" (тот же паттерн, что и
  // startSessionNow в Sidebar), затем переходим на /session/{id}
  // с реальным session_id — раньше ссылка вела на /session/{clientId},
  // и страница звонка не могла достать конкретную сессию из БД.
  async function startSessionNow() {
    if (!client || startingSession) return;
    setStartingSession(true);
    try {
      // Дата/время считаем в часовом поясе психолога, а не устройства —
      // иначе психолог, открывший кабинет с телефона в другом поясе
      // (или сервер, если бы кнопка когда-то стала server action),
      // создал бы сессию на "сейчас" по чужому времени.
      const now = new Date();
      const dateStr = formatDateInTimeZone(now, timeZone);
      const timeStr = formatTimeInTimeZone(now, timeZone);
      const created = await addSession({ clientId: client.id, clientName: client.name, date: dateStr, time: timeStr });
      router.push(`/session/${created.id}`);
    } finally {
      setStartingSession(false);
    }
  }

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(true);
  const [messengerLinks, setMessengerLinks] = useState<MessengerLink[]>([]);
  const [sendChannel, setSendChannel] = useState<"telegram" | "vk">("telegram");
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);
  const [inviteError, setInviteError] = useState<string | null>(null);
  const [inviteCopied, setInviteCopied] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [sending, setSending] = useState(false);
  const [showAttachPicker, setShowAttachPicker] = useState(false);
  const [attachItems, setAttachItems] = useState<KnowledgeAttachItem[]>([]);
  const [attachLoading, setAttachLoading] = useState(false);
  const [attachError, setAttachError] = useState<string | null>(null);
  const [attachSearch, setAttachSearch] = useState("");
  const [attachTypeFilter, setAttachTypeFilter] = useState<string>("");
  const [activeTab, setActiveTab] = useState<TabId>("sessions");
  const [exportingTranscripts, setExportingTranscripts] = useState(false);
  const [exportingSummaries, setExportingSummaries] = useState(false);
  const [exportingSelectedTranscripts, setExportingSelectedTranscripts] = useState(false);
  const [showPeriodSummary, setShowPeriodSummary] = useState(false);
  const [selectedSessionIds, setSelectedSessionIds] = useState<string[]>([]);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [periodSummaryResult, setPeriodSummaryResult] = useState<string | null>(null);
  const [periodSummaryError, setPeriodSummaryError] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [homeworkList, setHomeworkList] = useState<HomeworkItem[]>([]);
  const [testsLoading, setTestsLoading] = useState(true);
  const [showSendTestForm, setShowSendTestForm] = useState(false);
  const [newTestType, setNewTestType] = useState<TestType>("GAD7");
  const [newTestScore, setNewTestScore] = useState("");
  const [sendingTest, setSendingTest] = useState(false);
  const [sendingTestLink, setSendingTestLink] = useState(false);
  const [sendTestLinkError, setSendTestLinkError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    let cancelled = false;
    async function loadMessages() {
      setMessagesLoading(true);
      try {
        const res = await fetch(`/api/messages?client_id=${id}`);
        const data = await res.json();
        if (!cancelled && res.ok) {
          setMessages((data.messages ?? []).map(toChatMessage));
          setMessengerLinks(data.links ?? []);
          if ((data.links ?? []).some((l: MessengerLink) => l.platform === "vk")) setSendChannel("vk");
        }
      } finally {
        if (!cancelled) setMessagesLoading(false);
      }
    }
    loadMessages();
    return () => { cancelled = true; };
  }, [id]);

  // Отправленные клиенту домашние задания — без этого запроса карточка
  // показывала только счётчик из clients.hw_*, который никогда не
  // заполняется, и назначенные ДЗ нигде не были видны.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/clients/${id}/homework`);
        const data = await res.json();
        if (!cancelled && res.ok) setHomeworkList(data.homework ?? []);
      } catch {
        // молча: блок ДЗ покажет пустое состояние
      }
    })();
    return () => { cancelled = true; };
  }, [id]);

  useEffect(() => {
    let cancelled = false;
    async function loadTests() {
      setTestsLoading(true);
      try {
        const res = await fetch(`/api/clients/${id}/tests`);
        const data = await res.json();
        if (!cancelled && res.ok) {
          setTestResults(data.tests ?? []);
        }
      } finally {
        if (!cancelled) setTestsLoading(false);
      }
    }
    loadTests();
    return () => { cancelled = true; };
  }, [id]);

  const handleAddTestResult = async () => {
    const score = Number(newTestScore);
    if (Number.isNaN(score) || score < 0) return;
    setSendingTest(true);
    try {
      const res = await fetch("/api/tests/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ client_id: id, test_type: newTestType, score }),
      });
      const data = await res.json();
      if (res.ok) {
        setTestResults(prev => [...prev, data.test]);
        setNewTestScore("");
        setShowSendTestForm(false);
      } else {
        alert(data.error ?? "Не удалось сохранить результат теста");
      }
    } catch {
      // обрабатывается ниже общим catch/finally этой функции — см. исходный код
    } finally {
      setSendingTest(false);
    }
  };

  // Отправляет клиенту ссылку на реальную форму теста (/test/[token]) —
  // в отличие от handleAddTestResult выше (психолог сам вписывает балл
  // после устного опроса на сессии), здесь клиент сам проходит вопросы
  // по ссылке, а балл считается автоматически (см. /api/clients/[id]/tests/send
  // и src/lib/testQuestionnaires.ts). test_key интерактивного опросника
  // для клинических шкал совпадает с TestType (PHQ9/GAD7/...).
  const handleSendTestToClient = async () => {
    setSendingTestLink(true);
    setSendTestLinkError(null);
    try {
      const res = await fetch(`/api/clients/${id}/tests/send`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionnaire_key: newTestType, title: TEST_SCALES[newTestType].label }),
      });
      const data = await res.json();
      if (res.ok) {
        setShowSendTestForm(false);
      } else {
        setSendTestLinkError(data.error ?? "Не удалось отправить тест");
      }
    } catch {
      setSendTestLinkError("Не удалось связаться с сервером");
    } finally {
      setSendingTestLink(false);
    }
  };

  const clientSessions = useMemo(
    () => sessions.filter(s => s.clientId === id).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)),
    [sessions, id]
  );
  // Сегодняшняя дата в часовом поясе ПСИХОЛОГА: раньше здесь стояла
  // захардкоженная "2026-08-16" (прошедшие сессии показывались как
  // предстоящие), потом — дата устройства, что для психолога с поясом,
  // отличным от браузерного, на границе суток снова делило сессии
  // неверно.
  const today = useMemo(() => todayInTimeZone(timeZone), [timeZone]);
  // По моменту окончания, а не по дате — иначе только что проведённая
  // сессия до полуночи остаётся «предстоящей» с кнопкой «Начать».
  const upcomingSessions = clientSessions.filter(s => !isSessionPast(s.date, s.time, timeZone));
  const pastSessions = clientSessions.filter(s => isSessionPast(s.date, s.time, timeZone)).reverse();

  const progress = client?.progress ?? EMPTY_PROGRESS;
  // Реальная история теста — из test_results (Supabase). Пока психолог
  // ничего не внёс — используем demo-extras как наглядную заглушку
  // (только для показа UI, не смешивается с реальными данными после
  // первого сохранённого результата).
  const demoExtrasForTrend = demoClientExtrasByName[client?.name ?? ""];
  const completedTests = useMemo(() => testResults.filter(t => t.status === "completed"), [testResults]);
  const clientTestHistoryForTrend = completedTests.length > 0
    ? completedTests.map(t => ({ date: new Date(t.created_at).toLocaleDateString("ru", { day: "numeric", month: "short", timeZone }), score: t.score }))
    : demoExtrasForTrend?.testHistory ?? [];
  // Тренд считаем по истории теста (score ниже = лучше для GAD-7/PHQ-9/MBI,
  // поэтому направление здесь условное — просто "снизился/вырос за 2 замера").
  // Пока в БД нет флага "меньше = лучше" по методике, это грубое приближение
  // для демонстрации, не клиническая оценка.
  const trend = useMemo(() => {
    if (clientTestHistoryForTrend.length >= 2) {
      const recent = clientTestHistoryForTrend.slice(-2);
      if (recent[1].score < recent[0].score) return "improving";
      if (recent[1].score > recent[0].score) return "degrading";
      return "stable";
    }
    if (progress.history.length < 2) return "stable";
    const recent = progress.history.slice(-2);
    if (recent[1].aiScore > recent[0].aiScore) return "improving";
    if (recent[1].aiScore < recent[0].aiScore) return "degrading";
    return "stable";
  }, [progress, clientTestHistoryForTrend]);
  const trendColor = trend === "improving" ? "#1BAF7A" : trend === "degrading" ? "#EF4444" : "#F59E0B";
  const TrendIcon = trend === "improving" ? TrendingUp : trend === "degrading" ? TrendingDown : Minus;

  const sendMessage = async () => {
    if (!chatInput.trim() || sending) return;
    // Вложения пока не поддерживаются реальной отправкой — Telegram/VK
    // API для файлов требует отдельной загрузки, добавим отдельно.
    const text = chatInput;
    setChatInput("");
    setSending(true);
    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ client_id: id, text, channel: sendChannel }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessages(prev => [...prev, toChatMessage(data.message, timeZone)]);
        setSelectedFile(null);
      } else {
        setChatInput(text);
        alert(data.error ?? "Не удалось отправить сообщение");
      }
    } catch {
      setChatInput(text);
      alert("Не удалось связаться с сервером");
    } finally {
      setSending(false);
    }
  };

  // Открывает выбор материала из базы знаний для вставки в сообщение
  // клиенту — раньше в чате не было способа прикрепить готовую технику
  // или материал платформы, кроме ручного набора текста заново.
  const openAttachPicker = async () => {
    setShowAttachPicker(true);
    setAttachSearch("");
    setAttachTypeFilter("");
    if (attachItems.length > 0 || attachLoading) return;
    setAttachLoading(true);
    setAttachError(null);
    try {
      const res = await fetch("/api/knowledge");
      const data = await res.json();
      if (!res.ok) {
        setAttachError(data?.error ?? "Не удалось загрузить материалы");
        return;
      }
      setAttachItems(data.items ?? []);
    } catch {
      setAttachError("Не удалось связаться с сервером");
    } finally {
      setAttachLoading(false);
    }
  };

  // Вставляет текст материала в поле ввода — психолог может
  // отредактировать перед отправкой, а не отправляется напрямую, в
  // отличие от готовых ДЗ во вкладке "Шаблоны ДЗ" (там текст уже
  // адресован клиенту как есть, здесь материалы разного назначения).
  const attachMaterial = (item: KnowledgeAttachItem) => {
    setChatInput(prev => (prev ? `${prev}\n\n${item.content}` : item.content));
    setShowAttachPicker(false);
  };

  const filteredAttachItems = useMemo(() => {
    const query = attachSearch.trim().toLowerCase();
    return attachItems.filter(item => {
      const matchesType = !attachTypeFilter || item.source_type === attachTypeFilter;
      const matchesSearch = !query
        || (item.title ?? "").toLowerCase().includes(query)
        || item.content.toLowerCase().includes(query);
      return matchesType && matchesSearch;
    });
  }, [attachItems, attachSearch, attachTypeFilter]);

  const attachAvailableTypes = useMemo(
    () => Array.from(new Set(attachItems.map(i => i.source_type))),
    [attachItems]
  );

  const loadInviteLink = async () => {
    setInviteError(null);
    setInviteUrl(null);
    try {
      const res = await fetch(`/api/clients/${id}/messenger-link?platform=telegram`);
      const data = await res.json();
      if (data.linked) return; // уже привязан, баннер и так не покажется
      if (data.invite_url) setInviteUrl(data.invite_url);
      else setInviteError(data.error ?? "Не удалось получить ссылку-приглашение");
    } catch {
      setInviteError("Не удалось связаться с сервером");
    }
  };

  const copyInviteLink = () => {
    if (!inviteUrl) return;
    navigator.clipboard.writeText(inviteUrl);
    setInviteCopied(true);
    setTimeout(() => setInviteCopied(false), 2000);
  };

  if (clientsLoading) {
    return (
      <div style={{ textAlign: "center", padding: 40 }}>
        <p style={{ color: "#6F5A3F" }}>Загрузка…</p>
      </div>
    );
  }

  if (!client) {
    return (
      <div style={{ textAlign: "center", padding: 40 }}>
        <p style={{ color: "#6F5A3F" }}>Клиент не найден</p>
        <Link href="/clients" style={{ color: "#2D6A5C", fontSize: 13, fontWeight: 600 }}>← Все клиенты</Link>
      </div>
    );
  }

  const clientIdx = clients.indexOf(client);
  const avatarColor = avatarColors[clientIdx % avatarColors.length];
  // triggers/ДЗ пока остаются демо-заглушкой (см. lib/demo-client-extras.ts) —
  // тесты и прогресс теперь реальные (test_results в Supabase, см. выше).
  const demoExtras = demoClientExtrasByName[client.name];
  const clientTestHistory = clientTestHistoryForTrend;
  const triggers = client.triggers ?? demoExtras?.triggers ?? EMPTY_TRIGGERS;
  const latestCompletedTest = completedTests.length > 0 ? completedTests[completedTests.length - 1] : null;
  const lastTest = latestCompletedTest
    ? {
        name: testDisplayName(latestCompletedTest),
        score: latestCompletedTest.score,
        maxScore: latestCompletedTest.max_score,
        date: new Date(latestCompletedTest.created_at).toLocaleDateString("ru", { day: "numeric", month: "short", timeZone }),
      }
    : client.lastTest ?? demoExtras?.lastTest;
  const hwTotal = client.hwTotal || demoExtras?.hwTotal || 0;
  const hwCompleted = client.hwCompleted || demoExtras?.hwCompleted || 0;
  const hwPct = hwTotal > 0 ? Math.round((hwCompleted / hwTotal) * 100) : 0;

  // Общая логика скачивания файла из GET-эндпоинта экспорта (используется
  // для всех трёх кнопок выгрузки — все транскрипты, резюме, выбранные
  // транскрипты — различается только url и текст ошибки).
  const downloadExport = async (url: string, fallbackFilename: string, errorFallback: string) => {
    const res = await fetch(url);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data.error ?? errorFallback);
      return;
    }
    const blob = await res.blob();
    const disposition = res.headers.get("Content-Disposition") ?? "";
    const match = disposition.match(/filename="([^"]+)"/);
    const filename = match?.[1] ?? fallbackFilename;
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(objectUrl);
  };

  const handleExportAllTranscripts = async () => {
    setExportingTranscripts(true);
    try {
      await downloadExport(
        `/api/clients/${client.id}/export/transcripts`,
        "transcripts.txt",
        "Не удалось выгрузить транскрипты"
      );
    } catch {
      alert("Не удалось выгрузить транскрипты — проверьте соединение");
    } finally {
      setExportingTranscripts(false);
    }
  };

  const handleExportSummaries = async () => {
    setExportingSummaries(true);
    try {
      await downloadExport(
        `/api/clients/${client.id}/export/summaries`,
        "summaries.txt",
        "Не удалось выгрузить резюме"
      );
    } catch {
      alert("Не удалось выгрузить резюме — проверьте соединение");
    } finally {
      setExportingSummaries(false);
    }
  };

  const handleExportSelectedTranscripts = async () => {
    if (selectedSessionIds.length === 0) {
      setPeriodSummaryError("Выберите хотя бы одну сессию");
      return;
    }
    setExportingSelectedTranscripts(true);
    setPeriodSummaryError(null);
    try {
      await downloadExport(
        `/api/clients/${client.id}/export/transcripts?session_ids=${selectedSessionIds.join(",")}`,
        "transcripts.txt",
        "Не удалось выгрузить транскрипты выбранных сессий"
      );
    } catch {
      alert("Не удалось выгрузить транскрипты — проверьте соединение");
    } finally {
      setExportingSelectedTranscripts(false);
    }
  };

  const toggleSessionSelected = (sessionId: string) => {
    setSelectedSessionIds(prev =>
      prev.includes(sessionId) ? prev.filter(id => id !== sessionId) : [...prev, sessionId]
    );
  };

  const handleGenerateSummary = async () => {
    if (selectedSessionIds.length === 0) {
      setPeriodSummaryError("Выберите хотя бы одну сессию");
      return;
    }
    setGeneratingSummary(true);
    setPeriodSummaryError(null);
    setPeriodSummaryResult(null);
    try {
      const res = await fetch(`/api/clients/${client.id}/summary`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_ids: selectedSessionIds }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPeriodSummaryError(data.error ?? "Не удалось сгенерировать срез");
        return;
      }
      setPeriodSummaryResult(data.summary);
    } catch {
      setPeriodSummaryError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setGeneratingSummary(false);
    }
  };

  const handleDownloadSummary = () => {
    if (!periodSummaryResult) return;
    const blob = new Blob([periodSummaryResult], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `srez_${client.name.replace(/[^\p{L}\p{N}_-]+/gu, "_")}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const closePeriodSummaryModal = () => {
    setShowPeriodSummary(false);
    setSelectedSessionIds([]);
    setPeriodSummaryResult(null);
    setPeriodSummaryError(null);
  };

  return (
    <div style={{ maxWidth: 1200, margin: "0 auto", width: "100%" }}>
      {/* Кнопка назад + профиль-хедер */}
      <Link href="/clients" style={{ textDecoration: "none" }}>
        <button style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "8px 12px", background: "#F5F3EF",
          border: "1px solid #E5DFD5", borderRadius: 6,
          fontSize: 12, fontWeight: 600, color: "#1C1C1E",
          cursor: "pointer", marginBottom: 16,
        }}>
          <ChevronLeft size={14} /> Все клиенты
        </button>
      </Link>

      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "#FFFFFF", border: "1px solid #E5DFD5", borderRadius: 12,
        padding: "20px 24px", marginBottom: 20,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{
            width: 56, height: 56, background: avatarColor, borderRadius: "50%",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, fontWeight: 700, color: "#fff",
          }}>
            {client.initials}
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#1C1C1E" }}>{client.name}</div>
            <div style={{ fontSize: 13, color: "#6B6058", marginTop: 2 }}>
              {[client.age != null ? formatAge(client.age) : null, client.request || null]
                .filter(Boolean)
                .join(" · ")}
            </div>
          </div>
          <div style={{
            padding: "4px 10px",
            background: client.status === "active" ? "#E6F7F2" : client.status === "pause" ? "#FEF3C7" : "#F5F3EF",
            color: client.status === "active" ? "#157347" : client.status === "pause" ? "#92400E" : "#6F5A3F",
            borderRadius: 6, fontSize: 11, fontWeight: 700,
          }}>
            {client.status === "active" ? "Активный" : client.status === "pause" ? "На паузе" : "Завершено"}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button
            onClick={openEditClient}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "9px 14px", background: "#F5F3EF",
              border: "1px solid #E5DFD5", borderRadius: 8,
              fontSize: 13, fontWeight: 600, color: "#1C1C1E",
              cursor: "pointer",
            }}
          >
            Редактировать
          </button>
          <Button size="md" onClick={startSessionNow} disabled={startingSession}>
            {startingSession ? "Создаю сессию..." : <>Начать сессию <ArrowRight size={15} style={{ marginLeft: 8 }} /></>}
          </Button>
        </div>
      </div>

      {/* Табы */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20, borderBottom: "1px solid #E5DFD5" }}>
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: "10px 18px",
              background: "none",
              border: "none",
              borderBottom: activeTab === tab.id ? "2px solid #2D6A5C" : "2px solid transparent",
              fontSize: 13,
              fontWeight: 600,
              color: activeTab === tab.id ? "#2D6A5C" : "#6B6058",
              cursor: "pointer",
              transition: "all 0.2s",
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* СЕССИИ: список сессий клиента + чат */}
      {activeTab === "sessions" && (
        <div style={{ display: "flex", gap: 16, height: "calc(100vh - 340px)", minHeight: 480 }}>
          <div style={{ flex: "0 0 34%", display: "flex", flexDirection: "column", gap: 16, overflowY: "auto" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <button
                onClick={handleExportAllTranscripts}
                disabled={exportingTranscripts}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                  padding: "8px 12px", background: "#F5F3EF", border: "1px solid #E5DFD5",
                  borderRadius: 8, fontSize: 12, fontWeight: 600, color: "#1C1C1E",
                  cursor: exportingTranscripts ? "not-allowed" : "pointer", fontFamily: "var(--font-sans)",
                }}
              >
                <Download size={13} /> {exportingTranscripts ? "Готовлю..." : "Выгрузить все транскрипты"}
              </button>
              <button
                onClick={handleExportSummaries}
                disabled={exportingSummaries}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                  padding: "8px 12px", background: "#F5F3EF", border: "1px solid #E5DFD5",
                  borderRadius: 8, fontSize: 12, fontWeight: 600, color: "#1C1C1E",
                  cursor: exportingSummaries ? "not-allowed" : "pointer", fontFamily: "var(--font-sans)",
                }}
              >
                <Download size={13} /> {exportingSummaries ? "Готовлю..." : "Выгрузить резюме (SOAP)"}
              </button>
              <button
                onClick={() => setShowPeriodSummary(true)}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                  padding: "8px 12px", background: "#E8F2EF", border: "1px solid #2D6A5C40",
                  borderRadius: 8, fontSize: 12, fontWeight: 600, color: "#2D6A5C",
                  cursor: "pointer", fontFamily: "var(--font-sans)",
                }}
              >
                <Sparkles size={13} /> Выбрать сессии...
              </button>
            </div>
            <div>
              <h3 style={{ fontSize: 12, fontWeight: 700, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 10 }}>
                Предстоящие ({upcomingSessions.length})
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {upcomingSessions.length === 0 && (
                  <p style={{ fontSize: 12, color: "#6F5A3F" }}>Нет запланированных сессий</p>
                )}
                {upcomingSessions.map(s => (
                  <Card key={s.id}>
                    <CardContent className="pt-3 pb-3" style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <Clock size={13} style={{ color: "#2D6A5C" }} />
                        <span style={{ fontSize: 12, fontWeight: 600, color: "#1C1C1E" }}>{formatSessionDate(s.date)} · {s.time}</span>
                      </div>
                      <Link href={`/session/${s.id}`} style={{ textDecoration: "none" }}>
                        <Button size="sm">Начать</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            <div>
              <h3 style={{ fontSize: 12, fontWeight: 700, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 10 }}>
                Прошедшие ({pastSessions.length})
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {pastSessions.length === 0 && (
                  <p style={{ fontSize: 12, color: "#6F5A3F" }}>Пока нет прошедших сессий</p>
                )}
                {pastSessions.map(s => (
                  <Card key={s.id}>
                    <CardContent className="pt-3 pb-3" style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <Video size={13} style={{ color: "#6F5A3F" }} />
                      <span style={{ fontSize: 12, color: "#6B6058" }}>{formatSessionDate(s.date)} · {s.time}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Чат с клиентом */}
          <div style={{ flex: "0 0 66%", display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <Card style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
              <CardContent className="pt-4 flex-1 flex flex-col" style={{ minHeight: 0 }}>
                {/* Баннер привязки мессенджера — показываем, пока у клиента нет ни одной привязки */}
                {!messagesLoading && messengerLinks.length === 0 && (
                  <div style={{
                    padding: "10px 12px", background: "#FEF3C7", borderRadius: 8,
                    marginBottom: 10, fontSize: 12, color: "#92400E",
                  }}>
                    {inviteUrl ? (
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <Link2 size={13} style={{ flexShrink: 0 }} />
                        <span style={{ wordBreak: "break-all" }}>{inviteUrl}</span>
                        <button
                          onClick={copyInviteLink}
                          style={{ background: "none", border: "none", cursor: "pointer", color: "#92400E", display: "flex", alignItems: "center", gap: 3, fontSize: 12, fontWeight: 600 }}
                        >
                          {inviteCopied ? <Check size={12} /> : <Copy size={12} />} {inviteCopied ? "Скопировано" : "Скопировать"}
                        </button>
                      </div>
                    ) : inviteError ? (
                      <span>{inviteError}</span>
                    ) : (
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                        <span>Чат клиента не подключён — сообщения сохранятся, но не дойдут, пока клиент не подключит мессенджер.</span>
                        <button onClick={loadInviteLink} style={{ background: "none", border: "none", cursor: "pointer", color: "#92400E", fontWeight: 700, fontSize: 12, whiteSpace: "nowrap" }}>
                          Получить ссылку →
                        </button>
                      </div>
                    )}
                  </div>
                )}

                <div style={{ flex: 1, overflowY: "auto", marginBottom: 12 }}>
                  {messagesLoading && (
                    <p style={{ fontSize: 12, color: "#6F5A3F", textAlign: "center", marginTop: 20 }}>Загрузка переписки…</p>
                  )}
                  {!messagesLoading && messages.length === 0 && (
                    <p style={{ fontSize: 12, color: "#6F5A3F", textAlign: "center", marginTop: 20 }}>Переписки пока нет</p>
                  )}
                  {messages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      style={{
                        display: "flex",
                        justifyContent: msg.role === "psychologist" ? "flex-end" : "flex-start",
                        marginBottom: 8,
                      }}
                    >
                      <div style={{
                        maxWidth: "80%", padding: "8px 12px", borderRadius: 8,
                        background: msg.role === "psychologist" ? "#2D6A5C" : "#F5F3EF",
                        color: msg.role === "psychologist" ? "#fff" : "#1C1C1E",
                        fontSize: 12,
                      }}>
                        <p style={{ margin: 0 }}>{msg.text}</p>
                        {msg.file && (
                          <div style={{ fontSize: 10, opacity: 0.7, marginTop: 4 }}>
                            📎 {msg.file.name} ({msg.file.size})
                          </div>
                        )}
                        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
                          <span style={{ fontSize: 10, opacity: 0.6 }}>{msg.time}</span>
                          {msg.role === "psychologist" && msg.status === "pending" && (
                            <span style={{ fontSize: 10, opacity: 0.75 }} title={msg.errorMessage ?? "Клиент ещё не подключил чат"}>· не доставлено</span>
                          )}
                          {msg.role === "psychologist" && msg.status === "failed" && (
                            <span style={{ fontSize: 10, color: "#FCA5A5" }} title={msg.errorMessage ?? ""}>· ошибка отправки</span>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {messengerLinks.length > 1 && (
                  <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
                    {messengerLinks.map(l => (
                      <button
                        key={l.platform}
                        onClick={() => setSendChannel(l.platform)}
                        style={{
                          padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                          border: sendChannel === l.platform ? "1px solid #2D6A5C" : "1px solid #E5DFD5",
                          background: sendChannel === l.platform ? "#E8F2EF" : "#fff",
                          color: sendChannel === l.platform ? "#2D6A5C" : "#6B6058",
                          cursor: "pointer",
                        }}
                      >
                        {l.platform === "telegram" ? "Telegram" : "ВКонтакте"}
                      </button>
                    ))}
                  </div>
                )}

                <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
                  <div style={{ flex: 1 }}>
                    <textarea
                      value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                      onKeyPress={e => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      placeholder="Напишите сообщение..."
                      style={{
                        width: "100%", padding: "8px 12px",
                        border: "1px solid #E5DFD5", borderRadius: 6,
                        fontSize: 12, fontFamily: "var(--font-sans)",
                        color: "#1C1C1E", resize: "none", maxHeight: 80,
                        boxSizing: "border-box",
                      }}
                      rows={2}
                    />
                  </div>
                  <div style={{ display: "flex", gap: 4 }}>
                    <button
                      onClick={openAttachPicker}
                      title="Прикрепить материал из базы знаний"
                      style={{
                        width: 32, height: 32, background: "#F5F1E8",
                        border: "1px solid #E5DFD5", borderRadius: 6,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        cursor: "pointer", color: "#6B6058",
                      }}
                    >
                      <Paperclip size={16} />
                    </button>
                    <button
                      onClick={sendMessage}
                      disabled={sending || !chatInput.trim()}
                      style={{
                        width: 32, height: 32, background: sending || !chatInput.trim() ? "#A7C4BC" : "#2D6A5C",
                        border: "none", borderRadius: 6,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        cursor: sending || !chatInput.trim() ? "default" : "pointer", color: "#FFFFFF",
                      }}
                    >
                      <Send size={16} />
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Выбор материала из базы знаний для вставки в сообщение клиенту */}
      <AnimatePresence>
        {showAttachPicker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowAttachPicker(false)}
            style={{
              position: "fixed", inset: 0, background: "rgba(28,28,30,0.4)",
              display: "flex", alignItems: "center", justifyContent: "center",
              zIndex: 100, padding: 24,
            }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              onClick={(e) => e.stopPropagation()}
              style={{
                background: "#FFFFFF", borderRadius: 16, width: "100%", maxWidth: 520,
                maxHeight: "80vh", display: "flex", flexDirection: "column",
                boxShadow: "0 20px 60px rgba(0,0,0,0.25)", overflow: "hidden",
              }}
            >
              <div style={{
                padding: "18px 20px", borderBottom: "1px solid #EFEAE0",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <BookOpen size={16} style={{ color: "#2D6A5C" }} />
                  <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>
                    Прикрепить материал
                  </h3>
                </div>
                <button
                  onClick={() => setShowAttachPicker(false)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#6F5A3F", padding: 4 }}
                >
                  <X size={18} />
                </button>
              </div>

              {!attachLoading && !attachError && attachItems.length > 0 && (
                <div style={{ padding: "12px 20px 8px", display: "flex", flexDirection: "column", gap: 8 }}>
                  <div style={{ position: "relative" }}>
                    <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#6F5A3F" }} />
                    <input
                      value={attachSearch}
                      onChange={e => setAttachSearch(e.target.value)}
                      placeholder="Поиск по базе знаний..."
                      style={{
                        width: "100%", padding: "8px 10px 8px 32px", border: "1px solid #E5DFD5",
                        borderRadius: 8, fontSize: 13, color: "#1C1C1E", boxSizing: "border-box",
                        fontFamily: "var(--font-sans)",
                      }}
                    />
                  </div>
                  {attachAvailableTypes.length > 1 && (
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                      <button
                        onClick={() => setAttachTypeFilter("")}
                        style={{
                          padding: "4px 10px", borderRadius: 20, border: "none", cursor: "pointer",
                          fontSize: 11, fontWeight: 600, fontFamily: "var(--font-sans)",
                          background: attachTypeFilter === "" ? "#2D6A5C" : "#F5F3EF",
                          color: attachTypeFilter === "" ? "#FFFFFF" : "#6B6058",
                        }}
                      >
                        Все
                      </button>
                      {attachAvailableTypes.map(type => (
                        <button
                          key={type}
                          onClick={() => setAttachTypeFilter(prev => (prev === type ? "" : type))}
                          style={{
                            padding: "4px 10px", borderRadius: 20, border: "none", cursor: "pointer",
                            fontSize: 11, fontWeight: 600, fontFamily: "var(--font-sans)",
                            background: attachTypeFilter === type ? "#2D6A5C" : "#F5F3EF",
                            color: attachTypeFilter === type ? "#FFFFFF" : "#6B6058",
                          }}
                        >
                          {ATTACH_SOURCE_TYPE_LABELS[type] ?? type}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div style={{ overflowY: "auto", padding: "8px 12px", flex: 1 }}>
                {attachLoading && (
                  <div style={{ padding: 24, textAlign: "center", fontSize: 12, color: "#6F5A3F" }}>
                    Загрузка материалов...
                  </div>
                )}
                {attachError && !attachLoading && (
                  <div style={{ padding: 24, textAlign: "center", fontSize: 12, color: "#C0392B" }}>
                    {attachError}
                  </div>
                )}
                {!attachLoading && !attachError && attachItems.length === 0 && (
                  <div style={{ padding: 24, textAlign: "center", fontSize: 12, color: "#6F5A3F" }}>
                    В базе знаний пока нет материалов
                  </div>
                )}
                {!attachLoading && !attachError && attachItems.length > 0 && filteredAttachItems.length === 0 && (
                  <div style={{ padding: 24, textAlign: "center", fontSize: 12, color: "#6F5A3F" }}>
                    Ничего не найдено
                  </div>
                )}
                {!attachLoading && !attachError && filteredAttachItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => attachMaterial(item)}
                    style={{
                      width: "100%", textAlign: "left", background: "none", border: "none",
                      borderBottom: "1px solid #F5F1E8", padding: "12px 8px", cursor: "pointer",
                      display: "flex", flexDirection: "column", gap: 4, fontFamily: "var(--font-sans)",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{
                        fontSize: 10, fontWeight: 700, color: "#2D6A5C", background: "#E8F2EF",
                        padding: "2px 6px", borderRadius: 4, flexShrink: 0,
                      }}>
                        {ATTACH_SOURCE_TYPE_LABELS[item.source_type] ?? item.source_type}
                      </span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>
                        {item.title ?? "Без названия"}
                      </span>
                    </div>
                    <p style={{
                      fontSize: 12, color: "#6B6058", margin: 0, lineHeight: 1.5,
                      display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden",
                    }}>
                      {item.content}
                    </p>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* СВОДКА: профиль + ДЗ */}
      {activeTab === "summary" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <Card>
            <CardContent className="pt-6">
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E", marginBottom: 16 }}>Профиль</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 4 }}>Пол</div>
                  <div style={{ fontSize: 13, color: "#1C1C1E" }}>{client.gender === "female" ? "Женский" : "Мужской"}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 4 }}>Запрос</div>
                  <div style={{ fontSize: 13, color: "#1C1C1E" }}>{client.request}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 4 }}>Подход</div>
                  <div style={{ fontSize: 13, color: "#1C1C1E" }}>{APPROACH_LABELS[client.approach as Approach] ?? client.approach}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 4 }}>Всего сессий</div>
                  <div style={{ fontSize: 13, color: "#1C1C1E" }}>{clientSessions.length}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", marginBottom: 4 }}>Триггеры</div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {triggers.length === 0 && (
                      <span style={{ fontSize: 12, color: "#6F5A3F" }}>Пока не отмечены</span>
                    )}
                    {triggers.map((trigger, i) => (
                      <span key={i} style={{ padding: "4px 8px", background: "#E8F2EF", color: "#2D6A5C", borderRadius: 4, fontSize: 11 }}>
                        {trigger}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E", marginBottom: 16 }}>
                Домашние задания ({homeworkList.length})
              </h3>
              {/* Раньше здесь был счётчик hwCompleted/hwTotal из колонок
                  clients.hw_*, которые ничто не заполняет — он всегда
                  показывал 0/0, даже сразу после отправки задания, и
                  психолог нигде не видел, что именно задал. Показываем
                  реальные отправленные ДЗ (messages.kind='homework'). */}
              {homeworkList.length === 0 ? (
                <p style={{ fontSize: 12.5, color: "#6F5A3F", margin: 0, lineHeight: 1.5 }}>
                  Заданий пока нет. Отправить можно из раздела «База знаний» → «Шаблоны ДЗ»
                  или попросить ассистента.
                </p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {homeworkList.map(hw => (
                    <div key={hw.id} style={{ padding: "10px 12px", background: "#F5F3EF", borderRadius: 8 }}>
                      <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.5, whiteSpace: "pre-wrap" }}>
                        {hw.text.length > 220 ? `${hw.text.slice(0, 220)}…` : hw.text}
                      </div>
                      <div style={{ fontSize: 11, color: hw.status === "sent" ? "#157347" : "#6F5A3F", marginTop: 6 }}>
                        {new Date(hw.created_at).toLocaleDateString("ru", { day: "numeric", month: "long", timeZone })}
                        {" · "}
                        {hw.status === "sent" ? "доставлено" : "не доставлено — у клиента не подключён мессенджер"}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* АНАЛИТИКА: тесты + прогресс */}
      {activeTab === "analytics" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Card>
            <CardContent className="pt-6">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E" }}>
                  {lastTest?.name ? `Динамика теста ${lastTest.name}` : "Динамика тестов"}
                </h3>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  {/* Бейдж динамики показываем, только когда есть хотя бы
                      два замера, между которыми эта динамика и считается.
                      Раньше он висел всегда и у клиента без единого теста
                      бодро утверждал «Стабильно» — рядом с надписью
                      «Тесты ещё не проводились». */}
                  {testResults.length >= 2 && (
                    <div style={{
                      display: "flex", alignItems: "center", gap: 6,
                      padding: "5px 10px", background: `${trendColor}20`, borderRadius: 20,
                    }}>
                      <TrendIcon size={14} style={{ color: trendColor }} />
                      <span style={{ fontSize: 12, fontWeight: 600, color: trendColor }}>
                        {trend === "improving" ? "Улучшение" : trend === "degrading" ? "Ухудшение" : "Стабильно"}
                      </span>
                    </div>
                  )}
                  <Button size="sm" variant="secondary" onClick={() => setShowSendTestForm(v => !v)}>
                    + Внести результат теста
                  </Button>
                </div>
              </div>

              {showSendTestForm && (
                <div style={{
                  display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap",
                  padding: 12, background: "#F5F3EF", borderRadius: 8, marginBottom: 16,
                }}>
                  <select
                    value={newTestType}
                    onChange={e => setNewTestType(e.target.value as TestType)}
                    style={{
                      padding: "8px 10px", border: "1px solid #E5DFD5", borderRadius: 6,
                      fontSize: 12.5, color: "#1C1C1E", background: "#FFFFFF",
                    }}
                  >
                    {Object.entries(TEST_SCALES).map(([key, scale]) => (
                      <option key={key} value={key}>{scale.label}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={0}
                    max={TEST_SCALES[newTestType].maxScore}
                    value={newTestScore}
                    onChange={e => setNewTestScore(e.target.value)}
                    placeholder={`Балл (0–${TEST_SCALES[newTestType].maxScore})`}
                    style={{
                      width: 140, padding: "8px 10px", border: "1px solid #E5DFD5", borderRadius: 6,
                      fontSize: 12.5, color: "#1C1C1E", background: "#FFFFFF",
                    }}
                  />
                  <Button size="sm" onClick={handleAddTestResult} disabled={sendingTest || !newTestScore}>
                    {sendingTest ? "Сохранение…" : "Сохранить"}
                  </Button>
                  <Button size="sm" variant="secondary" onClick={handleSendTestToClient} disabled={sendingTestLink}>
                    {sendingTestLink ? "Отправляю…" : "Отправить клиенту ссылку на тест"}
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setShowSendTestForm(false)}>
                    Отмена
                  </Button>
                  {sendTestLinkError && (
                    <p style={{ width: "100%", fontSize: 12, color: "#B91C1C", margin: 0 }}>{sendTestLinkError}</p>
                  )}
                </div>
              )}

              {testsLoading ? (
                <p style={{ fontSize: 12, color: "#6F5A3F" }}>Загрузка истории тестов…</p>
              ) : clientTestHistory.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={clientTestHistory}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5DFD5" />
                    <XAxis dataKey="date" stroke="#6F5A3F" style={{ fontSize: 11 }} />
                    <YAxis stroke="#6F5A3F" style={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: "#fff", border: "1px solid #E5DFD5" }} />
                    <Line type="monotone" dataKey="score" stroke="#2D6A5C" strokeWidth={2} dot={{ fill: "#2D6A5C", r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <p style={{ fontSize: 12, color: "#6F5A3F" }}>Пока недостаточно данных теста для графика</p>
              )}
              <div style={{ marginTop: 12 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>
                  {lastTest
                    ? `Последний результат: ${lastTest.name} ${lastTest.score}/${lastTest.maxScore} (${lastTest.date})`
                    : "Тесты ещё не проводились"}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E", marginBottom: 16 }}>
                Оценка прогресса (ИИ / психолог / клиент)
              </h3>
              {/* Пустой график с осью −5…5 и без единой точки выглядел как
                  сломанный виджет, а не как «данных пока нет». */}
              {progress.history.length === 0 ? (
                <p style={{ fontSize: 13, color: "#6F5A3F", margin: 0, lineHeight: 1.5 }}>
                  График появится, когда накопятся оценки за несколько сессий — свою и клиента можно проставлять после каждой встречи.
                </p>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={progress.history}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5DFD5" />
                    <XAxis dataKey="date" stroke="#6F5A3F" style={{ fontSize: 11 }} />
                    <YAxis domain={[0, 10]} stroke="#6F5A3F" style={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: "#fff", border: "1px solid #E5DFD5" }} />
                    <Line type="monotone" dataKey="aiScore" name="ИИ" stroke="#2D6A5C" strokeWidth={2} dot={{ fill: "#2D6A5C", r: 3 }} />
                    <Line type="monotone" dataKey="psychologistScore" name="Психолог" stroke="#1BAF7A" strokeWidth={2} dot={{ fill: "#1BAF7A", r: 3 }} />
                    <Line type="monotone" dataKey="clientScore" name="Клиент" stroke="#F59E0B" strokeWidth={2} dot={{ fill: "#F59E0B", r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Модалка "Срез за период" */}
      {showPeriodSummary && (
        <>
          <div
            onClick={() => !generatingSummary && !exportingSelectedTranscripts && closePeriodSummaryModal()}
            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 70 }}
          />
          <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 75,
          }}>
            <div style={{
              background: "#FFFFFF", borderRadius: 16, width: "90%", maxWidth: 560,
              maxHeight: "85vh", overflowY: "auto", boxShadow: "0 25px 80px rgba(0,0,0,0.2)",
            }}>
              <div style={{
                padding: "18px 22px", borderBottom: "1px solid #E5DFD5",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <h2 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>
                  Выбранные сессии
                </h2>
                <button
                  onClick={() => !generatingSummary && !exportingSelectedTranscripts && closePeriodSummaryModal()}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#6F5A3F" }}
                >
                  <X size={18} />
                </button>
              </div>

              <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 14 }}>
                {!periodSummaryResult && (
                  <>
                    <div>
                      <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
                        Выберите сессии
                      </label>
                      <div style={{ display: "flex", flexDirection: "column", gap: 6, maxHeight: 240, overflowY: "auto" }}>
                        {clientSessions.length === 0 && (
                          <p style={{ fontSize: 12, color: "#6F5A3F" }}>У этого клиента пока нет сессий</p>
                        )}
                        {clientSessions.map(s => (
                          <label
                            key={s.id}
                            style={{
                              display: "flex", alignItems: "center", gap: 8,
                              padding: "8px 10px", background: "#F5F3EF", borderRadius: 8,
                              fontSize: 13, color: "#1C1C1E", cursor: "pointer",
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={selectedSessionIds.includes(s.id)}
                              onChange={() => toggleSessionSelected(s.id)}
                              style={{ accentColor: "#2D6A5C" }}
                            />
                            {s.date} · {s.time}
                          </label>
                        ))}
                      </div>
                    </div>

                    {periodSummaryError && (
                      <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", margin: 0 }}>
                        {periodSummaryError}
                      </p>
                    )}

                    <p style={{ fontSize: 11, color: "#6F5A3F", margin: 0, fontStyle: "italic" }}>
                      Списывает 1 запрос из лимита ассистента
                    </p>

                    <div style={{ display: "flex", gap: 8 }}>
                      <Button onClick={handleGenerateSummary} variant="primary" disabled={generatingSummary}>
                        {generatingSummary ? "Генерирую..." : "Сгенерировать срез"}
                      </Button>
                      <Button
                        onClick={handleExportSelectedTranscripts}
                        variant="secondary"
                        disabled={exportingSelectedTranscripts}
                      >
                        <Download size={14} style={{ marginRight: 6 }} />
                        {exportingSelectedTranscripts ? "Готовлю..." : "Выгрузить транскрипты"}
                      </Button>
                    </div>
                  </>
                )}

                {periodSummaryResult && (
                  <>
                    <div style={{
                      whiteSpace: "pre-wrap", fontSize: 13, color: "#1C1C1E",
                      lineHeight: 1.5, background: "#F5F3EF", borderRadius: 8, padding: 14,
                    }}>
                      {periodSummaryResult}
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <Button onClick={handleDownloadSummary} variant="secondary">
                        <Download size={14} style={{ marginRight: 6 }} /> Скачать
                      </Button>
                      <Button onClick={closePeriodSummaryModal} variant="secondary">
                        Закрыть
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Редактирование клиента: раньше карточку нельзя было изменить или
          архивировать никак — ни опечатку в имени поправить, ни завершить
          работу с клиентом. Фильтры "На паузе"/"Завершено" на /clients
          существовали, но выставить эти статусы было неоткуда. */}
      <AnimatePresence>
        {showEditClient && client && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !savingClient && setShowEditClient(false)}
              style={{ position: "fixed", inset: 0, background: "rgba(0, 0, 0, 0.4)", zIndex: 60, backdropFilter: "blur(2px)" }}
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 65 }}
            >
              <div style={{
                background: "#FFFFFF", borderRadius: 16, boxShadow: "0 25px 80px rgba(0,0,0,0.2)",
                width: "90%", maxWidth: 420, maxHeight: "85vh", overflowY: "auto",
              }}>
                <div style={{ padding: "20px 24px", borderBottom: "1px solid #E5DFD5", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <h2 style={{ fontSize: 16, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>Редактировать клиента</h2>
                  <button onClick={() => !savingClient && setShowEditClient(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "#6F5A3F", padding: 4 }}>
                    <X size={20} />
                  </button>
                </div>

                <div style={{ padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Имя *</label>
                    <input
                      value={editName}
                      onChange={e => setEditName(e.target.value)}
                      style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, fontFamily: "var(--font-sans)", boxSizing: "border-box" }}
                    />
                  </div>

                  <div style={{ display: "flex", gap: 10 }}>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Возраст</label>
                      <input
                        type="number"
                        value={editAge}
                        onChange={e => setEditAge(e.target.value)}
                        style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, fontFamily: "var(--font-sans)", boxSizing: "border-box" }}
                      />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Пол</label>
                      <select
                        value={editGender}
                        onChange={e => setEditGender(e.target.value as "male" | "female")}
                        style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, color: "#1C1C1E", fontFamily: "var(--font-sans)", background: "#FFFFFF" }}
                      >
                        <option value="female">Женский</option>
                        <option value="male">Мужской</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Запрос</label>
                    <input
                      value={editRequest}
                      onChange={e => setEditRequest(e.target.value)}
                      placeholder="Например: тревожность, панические атаки"
                      style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, fontFamily: "var(--font-sans)", boxSizing: "border-box" }}
                    />
                  </div>

                  <div>
                    <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Подход</label>
                    <input
                      value={editApproach}
                      onChange={e => setEditApproach(e.target.value)}
                      placeholder="Например: КПТ"
                      style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, fontFamily: "var(--font-sans)", boxSizing: "border-box" }}
                    />
                  </div>

                  <div>
                    <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Статус</label>
                    <select
                      value={editStatus}
                      onChange={e => setEditStatus(e.target.value as "active" | "pause" | "completed")}
                      style={{ width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, color: "#1C1C1E", fontFamily: "var(--font-sans)", background: "#FFFFFF" }}
                    >
                      <option value="active">Активный</option>
                      <option value="pause">На паузе</option>
                      <option value="completed">Завершено</option>
                    </select>
                  </div>

                  {editClientError && (
                    <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", margin: 0 }}>
                      {editClientError}
                    </p>
                  )}

                  <button
                    onClick={saveClientEdits}
                    disabled={savingClient}
                    style={{
                      marginTop: 4, padding: "12px", background: savingClient ? "#1F4E43" : "#2D6A5C",
                      color: "#fff", border: "none", borderRadius: 10, fontSize: 14, fontWeight: 600,
                      cursor: savingClient ? "not-allowed" : "pointer",
                    }}
                  >
                    {savingClient ? "Сохраняю..." : "Сохранить"}
                  </button>

                  <button
                    onClick={() => { setDeleteClientError(null); setShowDeleteClientConfirm(true); }}
                    disabled={savingClient}
                    style={{
                      padding: "10px", background: "none", color: "#B91C1C",
                      border: "1px solid #FCA5A5", borderRadius: 10, fontSize: 13, fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    Удалить клиента
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Подтверждение удаления — отдельный шаг, чтобы случайный клик не
          стёр карточку клиента со всей историей сессий. */}
      <AnimatePresence>
        {showDeleteClientConfirm && client && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => !deletingClient && setShowDeleteClientConfirm(false)}
              style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 70 }}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              style={{
                position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
                background: "#FFFFFF", borderRadius: 16, width: "90%", maxWidth: 380,
                zIndex: 75, boxShadow: "0 25px 80px rgba(0,0,0,0.2)", padding: 24,
              }}
            >
              <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 8 }}>
                Удалить {client.name}?
              </h3>
              <p style={{ fontSize: 13, color: "#6B6058", marginBottom: 20, lineHeight: 1.5 }}>
                Карточка, история сессий и переписка скроются из списка клиентов. Это действие нельзя отменить из интерфейса.
              </p>
              {deleteClientError && (
                <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", marginBottom: 16, marginTop: 0 }}>
                  {deleteClientError}
                </p>
              )}
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={() => setShowDeleteClientConfirm(false)}
                  disabled={deletingClient}
                  style={{ flex: 1, padding: "10px", background: "#F5F3EF", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, fontWeight: 600, color: "#1C1C1E", cursor: "pointer" }}
                >
                  Отмена
                </button>
                <button
                  onClick={confirmDeleteClient}
                  disabled={deletingClient}
                  style={{ flex: 1, padding: "10px", background: "#B91C1C", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, color: "#fff", cursor: deletingClient ? "not-allowed" : "pointer" }}
                >
                  {deletingClient ? "Удаляю..." : "Удалить"}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
