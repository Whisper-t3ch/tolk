"use client";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  User, Bell, Plug, CreditCard, Palette, ShieldCheck, AlertTriangle,
  ExternalLink, Sun, CalendarClock,
} from "lucide-react";
import { useProfile } from "@/lib/ProfileContext";
import PlanPickerModal from "@/components/PlanPickerModal";
import { Button, Card, CardContent, Badge } from "@/components/ui";

// Заявки на опасные действия (удаление аккаунта и т.п.) пока обрабатываются
// вручную через почту поддержки — отдельного API для этого ещё нет.

const SECTIONS = [
  { id: "notifications", label: "Уведомления", icon: Bell },
  { id: "integrations",  label: "Интеграции",  icon: Plug },
  { id: "billing",       label: "Тариф и оплата", icon: CreditCard },
  { id: "appearance",    label: "Внешний вид", icon: Palette },
  { id: "privacy",       label: "Конфиденциальность", icon: ShieldCheck },
  { id: "danger",        label: "Опасные действия", icon: AlertTriangle },
] as const;

type SectionId = typeof SECTIONS[number]["id"];

export default function SettingsPage() {
  const { profile, refresh: refreshProfile } = useProfile();
  const [activeSection, setActiveSection] = useState<SectionId>("notifications");
  const [showPlanPicker, setShowPlanPicker] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Лимит запросов к ассистенту — реальные данные из /api/assistant/limit,
  // а не мок currentPsychologist.plan.assistantRequests (в проде used/limit
  // зависят от тарифа психолога, см. PLAN_LIMITS в assistantLimits.ts).
  interface AssistantLimitInfo {
    used: number;
    limit: number;
    remaining: number;
    extra?: number;
    planName: string;
    planLabel: string;
  }
  const [limitInfo, setLimitInfo] = useState<AssistantLimitInfo | null>(null);
  const [limitLoading, setLimitLoading] = useState(true);

  useEffect(() => {
    const load = () =>
      fetch("/api/assistant/limit")
        .then(res => res.json())
        .then(data => { if (!data.error) setLimitInfo(data); })
        .finally(() => setLimitLoading(false));
    load();
    window.addEventListener("tolk:assistant-used", load);
    return () => window.removeEventListener("tolk:assistant-used", load);
  }, []);

  // Интеграции — реальные данные из /api/integrations, а не моки.
  interface Integration {
    platform: "telegram" | "vk";
    bot_username: string | null;
    status: "disconnected" | "connected" | "error";
    last_error: string | null;
  }
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [integrationsLoading, setIntegrationsLoading] = useState(true);
  const [showTelegramForm, setShowTelegramForm] = useState(false);
  const [showVkForm, setShowVkForm] = useState(false);
  const [telegramTokenInput, setTelegramTokenInput] = useState("");
  const [vkTokenInput, setVkTokenInput] = useState("");
  const [vkGroupIdInput, setVkGroupIdInput] = useState("");
  const [vkConfirmationInput, setVkConfirmationInput] = useState("");
  const [integrationSubmitting, setIntegrationSubmitting] = useState(false);
  const [integrationError, setIntegrationError] = useState<string | null>(null);
  const [vkSetupInfo, setVkSetupInfo] = useState<{ callback_url: string; secret_key: string } | null>(null);

  const loadIntegrations = async () => {
    try {
      const res = await fetch("/api/integrations");
      const data = await res.json();
      if (res.ok) setIntegrations(data.integrations ?? []);
    } finally {
      setIntegrationsLoading(false);
    }
  };

  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (SECTIONS.some(s => s.id === hash)) {
      setActiveSection(hash as SectionId);
    }
    loadIntegrations();
  }, []);

  const telegramIntegration = integrations.find(i => i.platform === "telegram");
  const vkIntegration = integrations.find(i => i.platform === "vk");

  const connectTelegram = async () => {
    if (!telegramTokenInput.trim()) return;
    setIntegrationSubmitting(true);
    setIntegrationError(null);
    try {
      const res = await fetch("/api/integrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform: "telegram", bot_token: telegramTokenInput.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setIntegrationError(data.error ?? "Не удалось подключить бота");
        return;
      }
      notify(`Telegram-бот @${data.integration.bot_username} подключён`);
      setShowTelegramForm(false);
      setTelegramTokenInput("");
      await loadIntegrations();
    } catch {
      setIntegrationError("Не удалось связаться с сервером");
    } finally {
      setIntegrationSubmitting(false);
    }
  };

  const connectVk = async () => {
    if (!vkTokenInput.trim() || !vkGroupIdInput.trim() || !vkConfirmationInput.trim()) return;
    setIntegrationSubmitting(true);
    setIntegrationError(null);
    try {
      const res = await fetch("/api/integrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform: "vk",
          bot_token: vkTokenInput.trim(),
          vk_group_id: vkGroupIdInput.trim(),
          confirmation_code: vkConfirmationInput.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setIntegrationError(data.error ?? "Не удалось подключить сообщество");
        return;
      }
      notify(`Сообщество «${data.integration.bot_username}» подключено`);
      if (data.setup_instructions?.callback_url) {
        setVkSetupInfo(data.setup_instructions);
      } else {
        setShowVkForm(false);
      }
      setVkTokenInput("");
      setVkGroupIdInput("");
      setVkConfirmationInput("");
      await loadIntegrations();
    } catch {
      setIntegrationError("Не удалось связаться с сервером");
    } finally {
      setIntegrationSubmitting(false);
    }
  };

  const disconnectIntegration = async (platform: "telegram" | "vk") => {
    await fetch(`/api/integrations?platform=${platform}`, { method: "DELETE" });
    notify(platform === "telegram" ? "Telegram отключён" : "ВКонтакте отключён");
    await loadIntegrations();
  };

  const requestsUsed = limitInfo?.used ?? profile?.plan.assistantRequests.used ?? 0;
  const extraCredits = limitInfo?.extra ?? profile?.plan.extra ?? 0;
  const totalRequests = limitInfo?.limit ?? profile?.plan.assistantRequests.total ?? 1;
  const creditPct = totalRequests > 0 ? Math.round((requestsUsed / totalRequests) * 100) : 0;
  const requestsRemaining = Math.max(0, totalRequests - requestsUsed);
  const planLabel = limitInfo?.planLabel ?? profile?.plan.name ?? "—";

  const notify = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  };

  async function reloadLimit() {
    const data = await fetch("/api/assistant/limit").then(r => r.json()).catch(() => null);
    if (data && !data.error) setLimitInfo(data);
    await refreshProfile();
  }

  async function requestExport() {
    try {
      const res = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Запрос на выгрузку моих данных (клиенты, сессии, заметки). Отправлено из Настройки → Конфиденциальность.", pageUrl: "/settings" }),
      });
      if (!res.ok) throw new Error();
      notify("Запрос отправлен. Подготовим выгрузку в течение 10 рабочих дней — ответ придёт в «Помощь»");
    } catch {
      notify("Не удалось отправить запрос — напишите в «Помощь»");
    }
  }

  async function buyCredits() {
    try {
      const res = await fetch("/api/assistant/credits", { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? "Не удалось начислить запросы");
      notify("Добавлено 100 запросов к лимиту");
      await reloadLimit();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Не удалось начислить запросы");
    }
  }

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px" }}>
      {showPlanPicker && (
        <PlanPickerModal
          currentKey={limitInfo?.planName ?? profile?.plan.key ?? ""}
          onClose={() => setShowPlanPicker(false)}
          onChanged={async label => {
            setShowPlanPicker(false);
            notify(`Тариф изменён: «${label}»`);
            await reloadLimit();
          }}
        />
      )}
      <h1 style={{ fontSize: 22, fontWeight: 700, color: "#1C1C1E", marginBottom: 20 }}>Настройки</h1>

      <div style={{ display: "flex", gap: 24 }}>
        {/* Боковая навигация настроек */}
        <div style={{ flex: "0 0 200px", display: "flex", flexDirection: "column", gap: 4 }}>
          <Link href="/profile" style={{ textDecoration: "none" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
              borderRadius: 8, color: "#6B6058", fontSize: 13, fontWeight: 600,
              marginBottom: 8, border: "1px solid #E5DFD5",
            }}>
              <User size={15} /> Профиль
              <ExternalLink size={12} style={{ marginLeft: "auto", opacity: 0.5 }} />
            </div>
          </Link>
          <Link href="/settings/booking" style={{ textDecoration: "none" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
              borderRadius: 8, color: "#6B6058", fontSize: 13, fontWeight: 600,
              marginBottom: 8, border: "1px solid #E5DFD5",
            }}>
              <CalendarClock size={15} /> Публичная запись
              <ExternalLink size={12} style={{ marginLeft: "auto", opacity: 0.5 }} />
            </div>
          </Link>
          {SECTIONS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveSection(id)}
              style={{
                display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
                borderRadius: 8, border: "none", cursor: "pointer", textAlign: "left",
                background: activeSection === id ? "#E8F2EF" : "transparent",
                color: activeSection === id ? "#2D6A5C" : id === "danger" ? "#B91C1C" : "#6B6058",
                fontSize: 13, fontWeight: activeSection === id ? 700 : 600,
                fontFamily: "var(--font-sans)",
              }}
            >
              <Icon size={15} /> {label}
            </button>
          ))}
        </div>

        {/* Контент раздела */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Без AnimatePresence mode="wait": в связке framer-motion 11 +
              React 19 выходящий блок зависал в состоянии opacity: 0, так и не
              завершив exit-анимацию, а новый раздел из-за режима "wait" вообще
              не монтировался. Панель намертво застревала на «Уведомлениях», и
              до интеграций (подключение Telegram/VK), тарифа, приватности и
              удаления аккаунта было не добраться ни кликом, ни по якорю
              вида /settings#integrations. Смена key сама размонтирует старый
              раздел и проигрывает появление нового — анимация сохраняется. */}
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.15 }}
            >
              {activeSection === "notifications" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 4 }}>Уведомления</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>
                      Уведомления о новых записях клиентов и ответах поддержки приходят в Telegram — подключите их в «Профиле». Остальные настройки (email/push) появятся в одном из ближайших обновлений:
                    </p>
                    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                      {[
                        { label: "Напоминания о сессиях", desc: "За 15 минут до начала" },
                        { label: "Сообщения от клиентов", desc: "Новые сообщения в чате" },
                        { label: "Выполнение домашних заданий", desc: "Когда клиент отмечает ДЗ выполненным" },
                        { label: "Новости продукта", desc: "Обновления и новые функции ТОЛК" },
                      ].map(item => (
                        <div key={item.label} style={{
                          display: "flex", alignItems: "center", justifyContent: "space-between",
                          padding: "12px 0", borderBottom: "1px solid #F5F3EF",
                        }}>
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>{item.label}</div>
                            <div style={{ fontSize: 12, color: "#6F5A3F" }}>{item.desc}</div>
                          </div>
                          <Badge variant="muted">Скоро</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {activeSection === "integrations" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 4 }}>Интеграции</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>Подключите каналы связи с клиентами — сообщения и домашние задания будут приходить прямо в мессенджер</p>

                    {integrationsLoading ? (
                      <p style={{ fontSize: 13, color: "#6F5A3F" }}>Загрузка…</p>
                    ) : (
                      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                        {/* Telegram */}
                        <div style={{ padding: "14px", background: "#F5F3EF", borderRadius: 10 }}>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                            <div>
                              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <span style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>Telegram</span>
                                {telegramIntegration?.status === "connected" && <Badge variant="success">Подключено</Badge>}
                                {telegramIntegration?.status === "error" && <Badge variant="danger">Ошибка</Badge>}
                              </div>
                              <div style={{ fontSize: 12, color: "#6F5A3F", marginTop: 2 }}>
                                {telegramIntegration?.status === "connected"
                                  ? `@${telegramIntegration.bot_username}`
                                  : telegramIntegration?.status === "error"
                                    ? telegramIntegration.last_error
                                    : "Бот не подключён"}
                              </div>
                            </div>
                            {telegramIntegration?.status === "connected" ? (
                              <Button variant="secondary" size="sm" onClick={() => disconnectIntegration("telegram")}>Отключить</Button>
                            ) : (
                              <Button variant="primary" size="sm" onClick={() => { setShowTelegramForm(v => !v); setIntegrationError(null); }}>
                                {showTelegramForm ? "Закрыть" : "Подключить"}
                              </Button>
                            )}
                          </div>

                          {showTelegramForm && telegramIntegration?.status !== "connected" && (
                            <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid #E5DFD5" }}>
                              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 14 }}>
                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>1</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    Откройте бота <strong>@BotFather</strong> в Telegram — это официальный сервис Telegram для создания ботов.
                                    <div style={{ marginTop: 6 }}>
                                      <a
                                        href="https://t.me/BotFather"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{
                                          display: "inline-flex", alignItems: "center", gap: 6,
                                          fontSize: 12.5, fontWeight: 600, color: "#2D6A5C", textDecoration: "none",
                                          background: "#E8F2EF", padding: "6px 12px", borderRadius: 8,
                                        }}
                                      >
                                        Открыть @BotFather <ExternalLink size={12} />
                                      </a>
                                    </div>
                                  </div>
                                </div>

                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>2</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    Отправьте команде <code style={{ background: "#F5F3EF", padding: "1px 5px", borderRadius: 4 }}>/newbot</code> и ответьте на два вопроса:
                                    <div style={{ marginTop: 6, background: "#F5F3EF", borderRadius: 8, padding: "8px 12px" }}>
                                      <div style={{ marginBottom: 4 }}>
                                        <span style={{ color: "#6B6058" }}>Имя бота (любое, видно клиентам): </span>
                                        <span style={{ fontFamily: "monospace" }}>Кабинет Марины Ивановой</span>
                                      </div>
                                      <div>
                                        <span style={{ color: "#6B6058" }}>Username (обязательно на bot): </span>
                                        <span style={{ fontFamily: "monospace" }}>marina_psy_bot</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>3</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    BotFather пришлёт длинный токен вида <span style={{ fontFamily: "monospace", color: "#6B6058" }}>123456:ABC-DEF...</span> — скопируйте его и вставьте ниже.
                                  </div>
                                </div>
                              </div>

                              <input
                                value={telegramTokenInput}
                                onChange={e => setTelegramTokenInput(e.target.value)}
                                placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                                style={{
                                  width: "100%", padding: "8px 12px", border: "1px solid #E5DFD5",
                                  borderRadius: 8, fontSize: 13, boxSizing: "border-box", marginBottom: 8,
                                  fontFamily: "monospace", color: "#1C1C1E", background: "#FFFFFF",
                                }}
                              />
                              {integrationError && <div style={{ fontSize: 12, color: "#B91C1C", marginBottom: 8 }}>{integrationError}</div>}
                              <Button size="sm" onClick={connectTelegram} disabled={integrationSubmitting || !telegramTokenInput.trim()}>
                                {integrationSubmitting ? "Проверяем…" : "Сохранить и подключить"}
                              </Button>
                            </div>
                          )}
                        </div>

                        {/* VK */}
                        <div style={{ padding: "14px", background: "#F5F3EF", borderRadius: 10 }}>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                            <div>
                              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <span style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>ВКонтакте</span>
                                {vkIntegration?.status === "connected" && <Badge variant="success">Подключено</Badge>}
                                {vkIntegration?.status === "error" && <Badge variant="danger">Ошибка</Badge>}
                              </div>
                              <div style={{ fontSize: 12, color: "#6F5A3F", marginTop: 2 }}>
                                {vkIntegration?.status === "connected"
                                  ? vkIntegration.bot_username
                                  : vkIntegration?.status === "error"
                                    ? vkIntegration.last_error
                                    : "Сообщество не подключено"}
                              </div>
                            </div>
                            {vkIntegration?.status === "connected" ? (
                              <Button variant="secondary" size="sm" onClick={() => disconnectIntegration("vk")}>Отключить</Button>
                            ) : (
                              <span style={{ fontSize: 12, fontWeight: 600, color: "#6F5A3F", background: "#EDE8DF", padding: "6px 12px", borderRadius: 999 }}>Скоро</span>
                            )}
                          </div>

                          {showVkForm && vkIntegration?.status !== "connected" && (
                            <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid #E5DFD5" }}>
                              <p style={{ fontSize: 12, color: "#6F5A3F", lineHeight: 1.6, marginBottom: 12 }}>
                                Нужно собственное сообщество ВКонтакте (если ещё нет — создайте на vk.com/groups → «Создать сообщество»).
                              </p>
                              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 14 }}>
                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>1</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    В настройках сообщества откройте <strong>Управление → Работа с API → Ключи доступа</strong> и создайте ключ сообщества — это и есть «Ключ доступа сообщества» ниже.
                                  </div>
                                </div>
                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>2</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    Там же, в разделе <strong>Callback API</strong>, нажмите «Включить» — появится код подтверждения, скопируйте его.
                                  </div>
                                </div>
                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>3</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    ID сообщества — число из ссылки на сообщество (например, <span style={{ fontFamily: "monospace" }}>vk.com/club<strong>123456</strong></span>) или из раздела «Управление».
                                  </div>
                                </div>
                                <div style={{ display: "flex", gap: 10 }}>
                                  <div style={{
                                    width: 22, height: 22, borderRadius: "50%", background: "#2D6A5C", color: "#fff",
                                    fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                                    flexShrink: 0, marginTop: 1,
                                  }}>4</div>
                                  <div style={{ fontSize: 12.5, color: "#1C1C1E", lineHeight: 1.6 }}>
                                    Заполните все три поля ниже и нажмите «Сохранить и подключить» — после этого мы покажем URL и секретный ключ для последнего шага в настройках Callback API.
                                  </div>
                                </div>
                              </div>
                              <input
                                value={vkTokenInput}
                                onChange={e => setVkTokenInput(e.target.value)}
                                placeholder="Ключ доступа сообщества"
                                style={{ width: "100%", padding: "8px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, boxSizing: "border-box", marginBottom: 8, fontFamily: "monospace", color: "#1C1C1E", background: "#FFFFFF" }}
                              />
                              <input
                                value={vkGroupIdInput}
                                onChange={e => setVkGroupIdInput(e.target.value)}
                                placeholder="ID сообщества"
                                style={{ width: "100%", padding: "8px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, boxSizing: "border-box", marginBottom: 8, color: "#1C1C1E", background: "#FFFFFF" }}
                              />
                              <input
                                value={vkConfirmationInput}
                                onChange={e => setVkConfirmationInput(e.target.value)}
                                placeholder="Код подтверждения Callback API"
                                style={{ width: "100%", padding: "8px 12px", border: "1px solid #E5DFD5", borderRadius: 8, fontSize: 13, boxSizing: "border-box", marginBottom: 8, fontFamily: "monospace", color: "#1C1C1E", background: "#FFFFFF" }}
                              />
                              {integrationError && <div style={{ fontSize: 12, color: "#B91C1C", marginBottom: 8 }}>{integrationError}</div>}
                              <Button
                                size="sm"
                                onClick={connectVk}
                                disabled={integrationSubmitting || !vkTokenInput.trim() || !vkGroupIdInput.trim() || !vkConfirmationInput.trim()}
                              >
                                {integrationSubmitting ? "Проверяем…" : "Сохранить и подключить"}
                              </Button>
                            </div>
                          )}

                          {vkSetupInfo && (
                            <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid #E5DFD5" }}>
                              <p style={{ fontSize: 12, color: "#6B6058", lineHeight: 1.6, marginBottom: 8 }}>
                                Осталось вставить эти значения в настройках Callback API сообщества:
                              </p>
                              <div style={{ fontSize: 11, fontFamily: "monospace", background: "#FFFFFF", padding: 10, borderRadius: 6, marginBottom: 6, wordBreak: "break-all" }}>
                                URL: {vkSetupInfo.callback_url}
                              </div>
                              <div style={{ fontSize: 11, fontFamily: "monospace", background: "#FFFFFF", padding: 10, borderRadius: 6, marginBottom: 8, wordBreak: "break-all" }}>
                                Секретный ключ: {vkSetupInfo.secret_key}
                              </div>
                              <Button size="sm" variant="secondary" onClick={() => { setVkSetupInfo(null); setShowVkForm(false); }}>Понятно</Button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {activeSection === "billing" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 4 }}>Тариф «{planLabel}»</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>
                      Бета-тестирование — тариф и оплата пока не подключены
                    </p>

                    {limitLoading ? (
                      <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 12 }}>Загрузка…</p>
                    ) : (
                      <>
                        <div style={{ padding: 12, background: "#F5F3EF", borderRadius: 8, marginBottom: 8 }}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12 }}>
                            <span style={{ color: "#6B6058" }}>
                              Запросы к ассистенту: {requestsUsed} / {totalRequests}
                              {extraCredits > 0 && <span style={{ color: "#157347" }}> (+{extraCredits})</span>}
                            </span>
                            <span style={{ color: requestsRemaining === 0 ? "#B91C1C" : "#2D6A5C", fontWeight: 600 }}>{creditPct}%</span>
                          </div>
                          <div style={{ height: 6, background: "rgba(79,126,255,0.1)", borderRadius: 4, overflow: "hidden" }}>
                            <div style={{
                              width: `${Math.min(100, creditPct)}%`, height: "100%",
                              background: requestsRemaining === 0 ? "#EF4444" : requestsRemaining <= 10 ? "#F59E0B" : "#2D6A5C",
                              borderRadius: 4, transition: "width 0.2s, background 0.2s",
                            }} />
                          </div>
                        </div>

                        {requestsRemaining === 0 && (
                          <div style={{ padding: "10px 12px", background: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 8, marginBottom: 12, fontSize: 12.5, color: "#B91C1C" }}>
                            Лимит запросов исчерпан — ассистент не будет отвечать до докупки или сброса в начале месяца.
                          </div>
                        )}
                        {requestsRemaining > 0 && requestsRemaining <= 10 && (
                          <div style={{ padding: "10px 12px", background: "#FEF3C7", border: "1px solid #FDE68A", borderRadius: 8, marginBottom: 12, fontSize: 12.5, color: "#92400E" }}>
                            Осталось всего {requestsRemaining} {requestsRemaining === 1 ? "запрос" : requestsRemaining < 5 ? "запроса" : "запросов"} до конца месяца.
                          </div>
                        )}
                      </>
                    )}

                    <div style={{ display: "flex", gap: 8 }}>
                      <Button onClick={buyCredits} variant={requestsRemaining === 0 ? "primary" : "secondary"} className="w-full">
                        Докупить +100 за 99 ₽
                      </Button>
                      <Button onClick={() => setShowPlanPicker(true)} variant="secondary" className="w-full">
                        Сменить тариф
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {activeSection === "appearance" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 4 }}>Внешний вид</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>Тема интерфейса приложения</p>
                    <div style={{
                      display: "flex", alignItems: "center", gap: 10,
                      padding: "14px 16px", border: "2px solid #2D6A5C", borderRadius: 10,
                      background: "#E8F2EF", maxWidth: 200,
                    }}>
                      <Sun size={20} style={{ color: "#2D6A5C" }} />
                      <span style={{ fontSize: 13, fontWeight: 600, color: "#2D6A5C" }}>Светлая</span>
                    </div>
                    <p style={{ fontSize: 12, color: "#6F5A3F", marginTop: 10 }}>
                      Тёмная тема и тема «как в системе» появятся в одном из ближайших обновлений.
                    </p>
                  </CardContent>
                </Card>
              )}

              {activeSection === "privacy" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", marginBottom: 4 }}>Конфиденциальность</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>Как хранятся и защищаются данные ваших клиентов</p>
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      {[
                        { title: "Серверы в РФ", desc: "Все данные клиентов хранятся на серверах, физически расположенных в России" },
                        { title: "Соответствие 152-ФЗ", desc: "Обработка персональных данных ведётся согласно требованиям закона о персональных данных" },
                        { title: "Шифрование", desc: "Данные передаются и хранятся в зашифрованном виде" },
                      ].map((item, i) => (
                        <div key={i} style={{ display: "flex", gap: 10, padding: "12px 14px", background: "#F5F3EF", borderRadius: 10 }}>
                          <ShieldCheck size={16} style={{ color: "#157347", flexShrink: 0, marginTop: 1 }} />
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600, color: "#1C1C1E" }}>{item.title}</div>
                            <div style={{ fontSize: 12, color: "#6B6058", marginTop: 2 }}>{item.desc}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <Button
                      onClick={requestExport}
                      variant="secondary" className="w-full" style={{ marginTop: 16 }}
                    >
                      Запросить выгрузку моих данных
                    </Button>
                    <p style={{ fontSize: 12, color: "#6F5A3F", marginTop: 8, lineHeight: 1.5 }}>
                      Мы подготовим архив ваших данных (клиенты, сессии, заметки) и отправим на вашу почту в течение 10 рабочих дней. Ответ придёт на странице «Помощь» и в Telegram, если он подключён.
                    </p>
                  </CardContent>
                </Card>
              )}

              {activeSection === "danger" && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 style={{ fontSize: 15, fontWeight: 700, color: "#B91C1C", marginBottom: 4 }}>Опасные действия</h3>
                    <p style={{ fontSize: 13, color: "#6F5A3F", marginBottom: 20 }}>Эти действия необратимы</p>
                    <Button onClick={() => setShowDeleteConfirm(true)} variant="danger" className="w-full">
                      Удалить аккаунт
                    </Button>
                  </CardContent>
                </Card>
              )}
            </motion.div>
        </div>
      </div>

      {/* Подтверждение удаления аккаунта */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowDeleteConfirm(false)}
              style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 40 }}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              style={{
                position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
                background: "#FFFFFF", borderRadius: 16, width: "90%", maxWidth: 420,
                zIndex: 45, boxShadow: "0 25px 80px rgba(0,0,0,0.2)", padding: 24,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <AlertTriangle size={20} style={{ color: "#B91C1C" }} />
                <h3 style={{ fontSize: 16, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>Удалить аккаунт?</h3>
              </div>
              <p style={{ fontSize: 13, color: "#6B6058", lineHeight: 1.5, marginBottom: 16 }}>
                Удаление аккаунта — необратимая операция, которую мы пока обрабатываем вручную, чтобы точно ничего не удалить по ошибке. Напишите нам через форму в разделе «Помощь» с темой «Удаление аккаунта» — подтвердим личность и удалим аккаунт вместе со всеми данными клиентов.
              </p>
              <div style={{ display: "flex", gap: 8 }}>
                <Button
                  onClick={() => setShowDeleteConfirm(false)}
                  variant="secondary" className="w-full"
                >
                  Отмена
                </Button>
                <Button
                  onClick={() => { setShowDeleteConfirm(false); window.location.href = "/help"; }}
                  variant="danger" className="w-full"
                >
                  Написать в поддержку
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Уведомление */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            style={{
              position: "fixed", top: 24, left: "50%", transform: "translateX(-50%)",
              background: "#157347", color: "#fff", padding: "12px 20px",
              borderRadius: 8, fontSize: 13, fontWeight: 600, zIndex: 60,
              boxShadow: "0 4px 12px rgba(27, 175, 122, 0.3)",
            }}
          >
            {notification}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
