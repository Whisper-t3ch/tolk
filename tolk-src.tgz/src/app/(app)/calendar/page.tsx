"use client";
import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ChevronLeft, ChevronRight, X, Video, Clock, Plus, Trash2 } from "lucide-react";
import { useSession } from "@/lib/SessionContext";
import { usePersonalEvents } from "@/lib/PersonalEventsContext";
import { findNearestFreeSlot } from "@/lib/calendarSlots";
import { Card, CardContent, Button } from "@/components/ui";

type SessionsByDay = Record<number, Array<{ clientId: string; clientName: string; time: string }>>;

function getSessionsByDay(sessions: any[], month: number, year: number): SessionsByDay {
  const result: SessionsByDay = {};

  sessions.forEach(session => {
    const [y, m, d] = session.date.split('-').map(Number);
    if (y === year && m === month + 1) {
      if (!result[d]) result[d] = [];
      result[d].push({
        clientId: session.clientId,
        clientName: session.clientName,
        time: session.time,
      });
    }
  });

  return result;
}

const clientColors = ["#2D6A5C", "#157347", "#B45309", "#B91C1C", "#6D28D9", "#0369A1"];
function colorForClient(clientId: string): string {
  let hash = 0;
  for (let i = 0; i < clientId.length; i++) hash = (hash * 31 + clientId.charCodeAt(i)) >>> 0;
  return clientColors[hash % clientColors.length];
}

// Унифицированная запись дня для боковой панели — сессии и личные дела
// вместе, отсортированные по времени, со скроллом если их много.
interface DayEntry {
  id?: string;
  time: string;
  kind: "session" | "personal";
  title: string;
  subtitle?: string;
  color?: string;
  clientId?: string;
}

const MAX_PREVIEW_ITEMS = 3;

function toDateStr(year: number, month: number, day: number): string {
  return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

export default function CalendarPage() {
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("09:00");
  const { sessions } = useSession();
  const { events: personalEvents, addEvent, removeEvent, updateEventTime } = usePersonalEvents();
  const sessionsByDay = getSessionsByDay(sessions, currentMonth.getMonth(), currentMonth.getFullYear());

  const personalEventsByDay = useMemo(() => {
    const result: Record<number, typeof personalEvents> = {};
    personalEvents.forEach(evt => {
      const [y, m, d] = evt.date.split("-").map(Number);
      if (y === currentMonth.getFullYear() && m === currentMonth.getMonth() + 1) {
        if (!result[d]) result[d] = [];
        result[d].push(evt);
      }
    });
    return result;
  }, [personalEvents, currentMonth]);

  const monthNames = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
  ];

  const getDaysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const getFirstDayOfMonth = (date: Date) => {
    const jsDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return jsDay === 0 ? 6 : jsDay - 1; // Пн = 0 ... Вс = 6
  };

  const daysInMonth = getDaysInMonth(currentMonth);
  const firstDay = getFirstDayOfMonth(currentMonth);
  const days: (number | null)[] = [];

  for (let i = 0; i < firstDay; i++) days.push(null);
  for (let i = 1; i <= daysInMonth; i++) days.push(i);

  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
    setSelectedDay(null);
    setShowAddForm(false);
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
    setSelectedDay(null);
    setShowAddForm(false);
  };

  const selectedDayEntries: DayEntry[] = useMemo(() => {
    if (selectedDay === null) return [];
    const entries: DayEntry[] = [];
    (sessionsByDay[selectedDay] ?? []).forEach(s => {
      entries.push({
        time: s.time,
        kind: "session",
        title: s.clientName,
        subtitle: "Сессия",
        color: colorForClient(s.clientId),
        clientId: s.clientId,
      });
    });
    (personalEventsByDay[selectedDay] ?? []).forEach(evt => {
      entries.push({ id: evt.id, time: evt.time, kind: "personal", title: evt.title });
    });
    return entries.sort((a, b) => a.time.localeCompare(b.time));
  }, [selectedDay, sessionsByDay, personalEventsByDay]);

  const selectedDate =
    selectedDay !== null
      ? new Date(currentMonth.getFullYear(), currentMonth.getMonth(), selectedDay)
      : null;

  // Занятые времена выбранного дня (сессии + личные дела) — используются
  // для автосдвига на ближайший свободный слот при добавлении/редактировании.
  const occupiedTimesForSelectedDay = useMemo(() => {
    if (selectedDay === null) return [];
    return selectedDayEntries.map(e => ({ time: e.time, id: e.id }));
  }, [selectedDay, selectedDayEntries]);

  const handleAddEvent = () => {
    if (selectedDay === null || !newTitle.trim()) return;
    const freeTime = findNearestFreeSlot(newTime, occupiedTimesForSelectedDay);
    addEvent({
      date: toDateStr(currentMonth.getFullYear(), currentMonth.getMonth(), selectedDay),
      time: freeTime,
      title: newTitle.trim(),
    });
    setNewTitle("");
    setNewTime("09:00");
    setShowAddForm(false);
  };

  const handleUpdateEventTime = (id: string, requestedTime: string) => {
    const freeTime = findNearestFreeSlot(requestedTime, occupiedTimesForSelectedDay, id);
    updateEventTime(id, freeTime);
  };

  return (
    <div style={{ maxWidth: selectedDay !== null ? 1560 : 1200, margin: "0 auto", padding: "0 24px", position: "relative", transition: "max-width 0.2s" }}>
      <h1 style={{
        fontSize: 24, fontWeight: 800, marginBottom: 24,
        background: "linear-gradient(135deg, #1C1C1E 0%, #2D6A5C 100%)",
        WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
        backgroundClip: "text", letterSpacing: "-0.3px",
      }}>
        Календарь
      </h1>

      <div style={{ display: "flex", gap: 16, alignItems: "flex-start", overflowX: "auto" }}>
        <div style={{ flex: "1 1 auto", minWidth: 640 }}>
          <Card style={{ overflow: "hidden" }}>
            <div style={{
              background: "linear-gradient(135deg, #2D6A5C 0%, #1E7F5F 100%)",
              padding: "18px 24px",
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <button
                onClick={prevMonth}
                style={{
                  width: 32, height: 32, borderRadius: 8, border: "none",
                  background: "rgba(255,255,255,0.18)", color: "#fff", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  transition: "background 0.15s",
                }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.32)")}
                onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.18)")}
              >
                <ChevronLeft size={16} />
              </button>
              <h2 style={{ fontSize: 18, fontWeight: 800, color: "#fff", margin: 0, letterSpacing: "-0.2px" }}>
                {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h2>
              <button
                onClick={nextMonth}
                style={{
                  width: 32, height: 32, borderRadius: 8, border: "none",
                  background: "rgba(255,255,255,0.18)", color: "#fff", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  transition: "background 0.15s",
                }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.32)")}
                onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.18)")}
              >
                <ChevronRight size={16} />
              </button>
            </div>
            <CardContent className="pt-6">

              {/* Дни недели */}
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                gap: 8,
                marginBottom: 16,
              }}>
                {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((day) => (
                  <div
                    key={day}
                    style={{
                      textAlign: "center",
                      fontSize: 12,
                      fontWeight: 600,
                      color: "#6F5A3F",
                      paddingBottom: 8,
                    }}
                  >
                    {day}
                  </div>
                ))}
              </div>

              {/* Календарь */}
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                gap: 8,
              }}>
                {days.map((day, idx) => {
                  const daySessions = day ? sessionsByDay[day] ?? [] : [];
                  const dayPersonal = day ? personalEventsByDay[day] ?? [] : [];
                  const totalCount = daySessions.length + dayPersonal.length;
                  const isToday = day === today.getDate() && currentMonth.getMonth() === today.getMonth() && currentMonth.getFullYear() === today.getFullYear();
                  const isSelected = day !== null && day === selectedDay;

                  // Превью: все события дня вместе, отсортированные по времени, максимум MAX_PREVIEW_ITEMS.
                  const previewEntries: DayEntry[] = [
                    ...daySessions.map(s => ({
                      time: s.time, kind: "session" as const, title: s.clientName, color: colorForClient(s.clientId),
                    })),
                    ...dayPersonal.map(evt => ({
                      time: evt.time, kind: "personal" as const, title: evt.title,
                    })),
                  ].sort((a, b) => a.time.localeCompare(b.time));
                  const shown = previewEntries.slice(0, MAX_PREVIEW_ITEMS);
                  const hiddenCount = totalCount - shown.length;

                  return (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.01 }}
                      onClick={() => day && (setSelectedDay(day), setShowAddForm(false))}
                      style={{
                        minHeight: 104,
                        padding: 8,
                        position: "relative",
                        overflow: "hidden",
                        background: isSelected
                          ? "linear-gradient(160deg, #E8F2EF 0%, #DCEEE8 100%)"
                          : isToday
                          ? "linear-gradient(160deg, #FFFFFF 0%, #F0F8F5 100%)"
                          : day ? "#FFFFFF" : "#FAF9F6",
                        border: isSelected ? "2px solid #2D6A5C" : isToday ? "1.5px solid #1BAF7A" : "1px solid #EDE8DF",
                        borderRadius: 10,
                        cursor: day ? "pointer" : "default",
                        transition: "all 0.2s",
                        boxShadow: isSelected ? "0 4px 14px rgba(45,106,92,0.18)" : "none",
                      }}
                      whileHover={day ? { y: -3, boxShadow: "0 10px 22px rgba(45,106,92,0.16)", borderColor: "#1BAF7A" } : {}}
                    >
                      {isToday && (
                        <div style={{
                          position: "absolute", top: 0, right: 0,
                          width: 0, height: 0,
                          borderStyle: "solid",
                          borderWidth: "0 18px 18px 0",
                          borderColor: "transparent #1BAF7A transparent transparent",
                        }} />
                      )}
                      {day && (
                        <>
                          <div style={{
                            fontSize: 14,
                            fontWeight: 800,
                            color: isToday ? "#157347" : "#1C1C1E",
                            marginBottom: 6,
                          }}>
                            {day}
                          </div>

                          <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                            {shown.map((entry, i) => (
                              <div
                                key={i}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 5,
                                  padding: "2px 5px 2px 4px",
                                  borderRadius: 5,
                                  background: entry.kind === "session" ? `${entry.color}18` : "#F5F3EF",
                                  borderLeft: `2.5px solid ${entry.kind === "session" ? entry.color : "#C9BFAE"}`,
                                }}
                              >
                                <span style={{
                                  fontSize: 9.5,
                                  fontWeight: entry.kind === "session" ? 700 : 500,
                                  color: entry.kind === "session" ? entry.color : "#6F5A3F",
                                  whiteSpace: "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                }}>
                                  {entry.time} · {entry.title}
                                </span>
                              </div>
                            ))}
                            {hiddenCount > 0 && (
                              <div style={{
                                fontSize: 9.5, color: "#fff", fontWeight: 700,
                                background: "#8C7355", borderRadius: 10,
                                padding: "1px 7px", alignSelf: "flex-start", marginTop: 1,
                              }}>
                                +{hiddenCount}
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Легенда */}
          <Card style={{ marginTop: 24 }}>
            <CardContent className="pt-6">
              <h3 style={{ fontSize: 14, fontWeight: 600, color: "#1C1C1E", marginBottom: 12 }}>
                Информация
              </h3>
              <p style={{ fontSize: 13, color: "#6B6058", margin: 0 }}>
                Кликните на число, чтобы открыть все события дня, добавить своё или изменить время личного дела (клик на время в списке справа). Сплошная граница — текущий день. Пунктирные карточки — личные дела (зал, семья, врач и т.д.).
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Боковая панель дня — со скроллом, если событий много */}
        <AnimatePresence>
          {selectedDay !== null && (
            <motion.div
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 24 }}
              style={{ width: 320, flexShrink: 0 }}
            >
              <Card style={{ position: "sticky", top: 16, maxWidth: 320, overflow: "hidden" }}>
                <div style={{
                  background: "linear-gradient(135deg, #2D6A5C 0%, #1E7F5F 100%)",
                  padding: "16px 20px",
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                }}>
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 800, color: "#fff", margin: 0, letterSpacing: "-0.2px" }}>
                      {selectedDate?.toLocaleDateString("ru", { day: "numeric", month: "long" })}
                    </h3>
                    <p style={{ fontSize: 11.5, color: "rgba(255,255,255,0.8)", margin: "2px 0 0 0" }}>
                      {selectedDayEntries.length === 0
                        ? "Событий нет"
                        : `${selectedDayEntries.length} ${selectedDayEntries.length === 1 ? "событие" : "событий"}`}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedDay(null)}
                    style={{
                      width: 28, height: 28, borderRadius: 8, border: "none",
                      background: "rgba(255,255,255,0.18)", cursor: "pointer", color: "#fff",
                      display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                    }}
                  >
                    <X size={15} />
                  </button>
                </div>
                <CardContent className="pt-6" style={{ display: "flex", flexDirection: "column", maxHeight: "calc(100vh - 200px)" }}>

                  <div style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 8,
                    overflowY: "auto",
                    paddingRight: 4,
                    marginBottom: 12,
                  }}>
                    {selectedDayEntries.map((entry, i) => {
                      const isPersonal = entry.kind === "personal" && entry.id;
                      const content = (
                        <div
                          style={{
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 10,
                            padding: "10px 12px",
                            borderRadius: 10,
                            background: entry.kind === "session" ? `${entry.color}12` : "#FAF9F6",
                            borderLeft: `3px solid ${entry.kind === "session" ? entry.color : "#C9BFAE"}`,
                            boxShadow: entry.kind === "session" ? `0 2px 8px ${entry.color}22` : "none",
                            cursor: entry.kind === "session" ? "pointer" : "default",
                            transition: "transform 0.15s",
                          }}
                        >
                          {isPersonal ? (
                            <input
                              type="time"
                              value={entry.time}
                              onClick={e => { e.preventDefault(); e.stopPropagation(); }}
                              onChange={e => handleUpdateEventTime(entry.id!, e.target.value)}
                              title="Изменить время"
                              style={{
                                flexShrink: 0,
                                minWidth: 76,
                                fontSize: 11.5,
                                fontWeight: 700,
                                color: "#6F5A3F",
                                border: "1px solid #E5DFD5",
                                borderRadius: 5,
                                padding: "2px 4px",
                                background: "#FFFFFF",
                                cursor: "pointer",
                              }}
                            />
                          ) : (
                            <div style={{
                              display: "flex", alignItems: "center", gap: 4, flexShrink: 0,
                              fontSize: 11.5, fontWeight: 700, color: entry.color,
                              minWidth: 42,
                            }}>
                              <Clock size={11} />
                              {entry.time}
                            </div>
                          )}
                          <div style={{ minWidth: 0, flex: 1 }}>
                            <div style={{
                              fontSize: 13, fontWeight: 600, color: "#1C1C1E",
                              display: "flex", alignItems: "center", gap: 6,
                            }}>
                              {entry.title}
                              {entry.kind === "session" && <Video size={12} style={{ color: entry.color, opacity: 0.7 }} />}
                            </div>
                            {entry.subtitle && (
                              <div style={{ fontSize: 11, color: "#6F5A3F", marginTop: 2 }}>{entry.subtitle}</div>
                            )}
                          </div>
                          {isPersonal && (
                            <button
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeEvent(entry.id!); }}
                              title="Удалить"
                              style={{ background: "none", border: "none", cursor: "pointer", color: "#6F5A3F", padding: 2, flexShrink: 0 }}
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </div>
                      );
                      return entry.kind === "session" && entry.clientId ? (
                        <Link key={i} href={`/clients/${entry.clientId}`} style={{ textDecoration: "none" }}>
                          {content}
                        </Link>
                      ) : (
                        <div key={i}>{content}</div>
                      );
                    })}
                  </div>

                  {showAddForm ? (
                    <div style={{ borderTop: "1px solid #E5DFD5", paddingTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
                      <input
                        type="time"
                        value={newTime}
                        onChange={e => setNewTime(e.target.value)}
                        style={{
                          padding: "8px 8px", border: "1px solid #E5DFD5", borderRadius: 6,
                          fontSize: 12, color: "#1C1C1E", background: "#FFFFFF",
                        }}
                      />
                      <input
                        type="text"
                        value={newTitle}
                        onChange={e => setNewTitle(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") handleAddEvent(); }}
                        placeholder="Название дела (например, Зал)"
                        autoFocus
                        style={{
                          padding: "8px 10px", border: "1px solid #E5DFD5", borderRadius: 6,
                          fontSize: 12.5, color: "#1C1C1E", background: "#FFFFFF",
                        }}
                      />
                      <div style={{ display: "flex", gap: 8 }}>
                        <Button onClick={handleAddEvent} size="sm" style={{ flex: 1 }}>
                          Добавить
                        </Button>
                        <Button onClick={() => setShowAddForm(false)} variant="secondary" size="sm">
                          Отмена
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowAddForm(true)}
                      style={{
                        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                        padding: "11px 12px",
                        background: "linear-gradient(135deg, #2D6A5C 0%, #1E7F5F 100%)",
                        border: "none",
                        borderRadius: 10, cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 700,
                        marginTop: "auto",
                        boxShadow: "0 4px 12px rgba(45,106,92,0.28)",
                        transition: "transform 0.15s",
                      }}
                      onMouseEnter={e => (e.currentTarget.style.transform = "translateY(-1px)")}
                      onMouseLeave={e => (e.currentTarget.style.transform = "translateY(0)")}
                    >
                      <Plus size={14} /> Добавить событие
                    </button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
