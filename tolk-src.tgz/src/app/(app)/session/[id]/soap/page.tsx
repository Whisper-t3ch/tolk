"use client";
import { use, useState, useEffect, useCallback, useMemo, type ChangeEvent } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { Download, Copy, FileOutput, CheckCircle, Sparkles, Send, X, Loader2, AlertTriangle } from "lucide-react";
import { Button, Card, CardContent } from "@/components/ui";
import { useProfile } from "@/lib/ProfileContext";
import { normalizeTimeZone } from "@/lib/timezone";
import { AI_DRAFT_NOTICE, GUARD_REPLACED_NOTICE } from "@/lib/soap/messages";

// Статус session.recording_status (см. migration_007_video_asr.sql) —
// подсказка психологу, почему автоматическая генерация SOAP пока
// недоступна (или уже скоро будет). "none" — запись не велась вообще
// (например, звонок был вне платформы) — тогда подсказка не нужна.
function recordingStatusHint(status: string) {
  if (status === "recording" || status === "processing") {
    return (
      <div style={{
        display: "flex", alignItems: "center", gap: 6, justifyContent: "center",
        fontSize: 12, color: "#6F5A3F", marginBottom: 12,
      }}>
        <Loader2 size={13} className="animate-spin" />
        Запись обрабатывается, расшифровка появится автоматически
      </div>
    );
  }
  // 25.09.2026: 'uploading' — остановка записи ещё не подтверждена или
  // фрагменты ещё дозагружаются (см. claude/recording-stop-fix-plan.md
  // в проекте) — статус обновится сам, как только сервер это увидит;
  // не ошибка, но психолог не должен думать, что всё уже готово.
  if (status === "uploading") {
    return (
      <div style={{
        display: "flex", alignItems: "center", gap: 6, justifyContent: "center",
        fontSize: 12, color: "#6F5A3F", marginBottom: 12,
      }}>
        <Loader2 size={13} className="animate-spin" />
        Запись ещё дозагружается — статус обновится автоматически, обновите страницу позже
      </div>
    );
  }
  // 'incomplete' — manifest не сошёлся с реестром доказанно (дыра в
  // нумерации и т.п.), само не исправится — в отличие от 'uploading'.
  if (status === "incomplete") {
    return (
      <div style={{
        display: "flex", alignItems: "center", gap: 6, justifyContent: "center",
        fontSize: 12, color: "#B91C1C", marginBottom: 12,
      }}>
        <AlertTriangle size={13} />
        Запись сохранена не полностью — часть разговора может отсутствовать
      </div>
    );
  }
  // 'manual_review_required' — автоматическая обработка остановлена намеренно
  // (например, не удалось безопасно обезличить текст): сырой текст дальше не
  // шёл, расшифровка и черновик не создавались.
  if (status === "manual_review_required") {
    return (
      <div style={{
        display: "flex", alignItems: "center", gap: 6, justifyContent: "center",
        fontSize: 12, color: "#B45309", marginBottom: 12,
      }}>
        <AlertTriangle size={13} />
        Автоматическая обработка записи остановлена: не удалось безопасно обезличить текст. Запись сохранена — заполните протокол вручную
      </div>
    );
  }
  if (status === "failed") {
    return (
      <div style={{
        display: "flex", alignItems: "center", gap: 6, justifyContent: "center",
        fontSize: 12, color: "#B91C1C", marginBottom: 12,
      }}>
        <AlertTriangle size={13} />
        Не удалось расшифровать запись — заполните протокол вручную
      </div>
    );
  }
  return null;
}

// Русскоязычный формат протокола сессии — вместо медицинской
// англоязычной аббревиатуры SOAP используется структура, отражающая
// то, как реально ведут записи консультирующие психологи в России:
// жалоба и запрос клиента его словами → контекст и наблюдения →
// гипотеза психолога → договорённости и план. Поля в БД (s_subjective/
// o_objective/a_assessment/p_plan) переиспользуются как есть — это
// просто новые русские подписи и подсказки поверх тех же 4 колонок,
// без миграции схемы.
const PROTOCOL_BLOCKS = [
  { key: "s" as const, label: "Жалоба и запрос клиента", color: "#2D6A5C", emoji: "💬", hint: "Своими словами клиента — что беспокоит, чего хочет добиться" },
  { key: "o" as const, label: "Контекст и наблюдения", color: "#157347", emoji: "👁", hint: "Что происходило на сессии: факты, поведение, выполнение ДЗ, результаты тестов" },
  { key: "a" as const, label: "Гипотеза психолога", color: "#92400E", emoji: "🧠", hint: "Ваш клинический анализ, динамика по сравнению с прошлыми сессиями" },
  { key: "p" as const, label: "Договорённости и план", color: "#6D28D9", emoji: "📋", hint: "Домашнее задание, фокус следующей сессии" },
];

interface SoapContent {
  s: string;
  o: string;
  a: string;
  p: string;
}

const EMPTY_SOAP: SoapContent = { s: "", o: "", a: "", p: "" };

// Текст рядом со спиннером кнопки генерации — асинхронный режим (см.
// комментарий в handleGenerate) занимает от десятков секунд до пары минут,
// и голый спиннер без пояснения в этом случае выглядит как зависший баг,
// а не как ожидаемое поведение.
function generateButtonLabel(stage: "starting" | "waiting" | null): string {
  if (stage === "starting") return "Запускаю генерацию…";
  if (stage === "waiting") return "Генерирую… обычно 1-2 минуты";
  return "Сгенерировать протокол";
}

interface ProtocolTemplate {
  id: string;
  title: string | null;
  content?: string;
}

export default function SOAPPage({ params }: { params: Promise<{ id: string }> }) {
  const { profile } = useProfile();
  const timeZone = normalizeTimeZone(profile?.timezone);
  const { id: sessionId } = use(params);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [sessionInfo, setSessionInfo] = useState<{ clientName: string; scheduledAt: string; durationMinutes: number; recordingStatus: string } | null>(null);
  const [soapNoteId, setSoapNoteId] = useState<string | null>(null);
  const [content, setContent] = useState<SoapContent>(EMPTY_SOAP);
  const [protocolExists, setProtocolExists] = useState(false);
  // Черновик создан ИИ — показываем явную пометку «AI-черновик, требует проверки».
  const [aiGenerated, setAiGenerated] = useState(false);
  // Разделы, где в записи не нашлось оснований и содержимое заменено на «Недостаточно данных».
  const [guardReplaced, setGuardReplaced] = useState(false);
  const [templates, setTemplates] = useState<ProtocolTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [downloadingTranscript, setDownloadingTranscript] = useState(false);
  const [showUploadTranscript, setShowUploadTranscript] = useState(false);
  const [uploadTranscriptText, setUploadTranscriptText] = useState("");
  const [uploadingTranscript, setUploadingTranscript] = useState(false);
  const [uploadTranscriptError, setUploadTranscriptError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [generateError, setGenerateError] = useState<string | null>(null);
  // Генерация теперь асинхронная (см. api/.../soap/generate) — занимает от
  // нескольких десятков секунд до пары минут вместо мгновенного ответа.
  // generateStage отражает это психологу текстом рядом со спиннером, а не
  // молчаливым ожиданием — иначе долгий спиннер выглядит зависшим багом.
  const [generateStage, setGenerateStage] = useState<"starting" | "waiting" | null>(null);
  const [showSendSummary, setShowSendSummary] = useState(false);
  const [summaryDraft, setSummaryDraft] = useState("");
  const [summaryChannel, setSummaryChannel] = useState<"telegram" | "vk" | "max">("telegram");
  const [sendingSummary, setSendingSummary] = useState(false);
  const [sendSummaryError, setSendSummaryError] = useState<string | null>(null);

  const loadSoap = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/soap`);
      const data = await res.json();
      if (!res.ok) {
        setLoadError(data.error ?? "Не удалось загрузить протокол");
        return;
      }
      setSessionInfo({
        clientName: data.session.clientName,
        scheduledAt: data.session.scheduledAt,
        durationMinutes: data.session.durationMinutes,
        recordingStatus: data.session.recordingStatus ?? "none",
      });
      setTemplates(data.templates ?? []);
      if (data.soapNote) {
        setSoapNoteId(data.soapNote.id);
        setContent({ s: data.soapNote.s, o: data.soapNote.o, a: data.soapNote.a, p: data.soapNote.p });
        setProtocolExists(true);
        setAiGenerated(data.soapNote.aiGenerated === true);
        setSelectedTemplateId(data.soapNote.protocolTemplateId ?? "");
      } else {
        setAiGenerated(false);
        setSoapNoteId(null);
        setContent(EMPTY_SOAP);
        setProtocolExists(false);
      }
    } catch {
      setLoadError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    loadSoap();
  }, [loadSoap]);

  async function handleSave() {
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/soap`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...content, protocol_template_id: selectedTemplateId || null }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSaveError(data.error ?? "Не удалось сохранить протокол");
        return;
      }
      setSoapNoteId(data.soapNote.id);
      setProtocolExists(true);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setSaveError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setSaving(false);
    }
  }

  // Генерация протокола — асинхронная (см. комментарий в api/.../soap/generate
  // про экономику: async-режим YandexGPT примерно вдвое дешевле синхронного,
  // психолог всё равно запускает генерацию уже после сессии, задержка в
  // 2-4 минуты не мешает). Здесь: (1) запускаем job, (2) опрашиваем статус
  // раз в 4 секунды, пока не готово, (3) подставляем результат так же, как
  // раньше делал единственный синхронный fetch.
  async function handleGenerate() {
    setGenerating(true);
    setGenerateError(null);
    setGenerateStage("starting");
    try {
      const startRes = await fetch(`/api/sessions/${sessionId}/soap/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ template_id: selectedTemplateId || undefined }),
      });
      const startData = await startRes.json();
      if (!startRes.ok) {
        // insufficient_data / manual_review_required — штатные отказные сценарии:
        // понятное сообщение, подсказка и ручное заполнение (блоки ниже).
        const base = startData.error ?? "Не удалось запустить генерацию протокола";
        setGenerateError(startData.hint ? `${base}. ${startData.hint}` : base);
        return;
      }

      const jobId = startData.jobId as string;
      setGenerateStage("waiting");

      const POLL_INTERVAL_MS = 4000;
      const MAX_ATTEMPTS = 60; // до 4 минут — async обычно укладывается в 1-2 минуты

      for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
        await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));

        const statusRes = await fetch(`/api/sessions/${sessionId}/soap/generate/status?job_id=${jobId}`);
        const statusData = await statusRes.json();
        if (!statusRes.ok) {
          setGenerateError(statusData.error ?? "Не удалось проверить статус генерации");
          return;
        }

        if (statusData.status === "error" || statusData.status === "manual_review_required") {
          setGenerateError(statusData.error ?? "Не удалось сгенерировать протокол");
          return;
        }

        if (statusData.status === "done") {
          const soapNote = statusData.soapNote;
          setSoapNoteId(soapNote.id);
          setContent({ s: soapNote.s, o: soapNote.o, a: soapNote.a, p: soapNote.p });
          setProtocolExists(true);
          setAiGenerated(true);
          setGuardReplaced(Array.isArray(statusData.guardIssues) && statusData.guardIssues.length > 0);
          setNotification("AI-черновик готов — проверьте и отредактируйте перед использованием");
          setTimeout(() => setNotification(null), 4000);
          return;
        }
        // status === "pending" — ждём следующей попытки.
      }

      setGenerateError("Генерация занимает необычно много времени — попробуйте обновить страницу через минуту, протокол мог уже сохраниться");
    } catch {
      setGenerateError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setGenerating(false);
      setGenerateStage(null);
    }
  }

  async function handleDownloadTranscript() {
    setDownloadingTranscript(true);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/export/transcript`);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setNotification(data.error ?? "Не удалось скачать транскрипт");
        setTimeout(() => setNotification(null), 3000);
        return;
      }
      const blob = await res.blob();
      const disposition = res.headers.get("Content-Disposition") ?? "";
      const match = disposition.match(/filename="([^"]+)"/);
      const filename = match?.[1] ?? "transcript.txt";
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setNotification("Не удалось скачать транскрипт — проверьте соединение");
      setTimeout(() => setNotification(null), 3000);
    } finally {
      setDownloadingTranscript(false);
    }
  }

  // Ручная загрузка транскрипта — для сессий, проведённых не через
  // видеозвонок платформы (очная встреча, звонок в другом сервисе), или
  // когда автоматическая расшифровка не удалась. Текст проходит тот же
  // путь, что и запись от GigaAM (анонимизация + embedding для RAG),
  // см. api/sessions/[id]/transcript/route.ts.
  async function handleUploadTranscript() {
    const text = uploadTranscriptText.trim();
    if (!text) {
      setUploadTranscriptError("Вставьте текст транскрипта");
      return;
    }
    setUploadingTranscript(true);
    setUploadTranscriptError(null);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/transcript`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (!res.ok) {
        setUploadTranscriptError(data.error ?? "Не удалось загрузить транскрипт");
        return;
      }
      setShowUploadTranscript(false);
      setUploadTranscriptText("");
      setNotification(
        data.embeddingSaved
          ? "Транскрипт загружен — теперь его можно использовать в ассистенте и для генерации протокола"
          : "Транскрипт загружен, но не удалось построить индекс для поиска — попробуйте позже"
      );
      setTimeout(() => setNotification(null), 4000);
      // recording_status на странице обновится при следующей загрузке —
      // не критично для этого действия, поэтому просто перезагружаем soap.
      loadSoap();
    } catch {
      setUploadTranscriptError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setUploadingTranscript(false);
    }
  }

  async function handleTranscriptFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.name.toLowerCase().endsWith(".docx")) {
      setUploadTranscriptError("Файлы .docx пока не поддерживаются — откройте файл и вставьте текст вручную, либо сохраните его как .txt");
      return;
    }
    const text = await file.text();
    setUploadTranscriptText(text);
    setUploadTranscriptError(null);
  }

  // Короткий дружелюбный текст для клиента из S+P — не клинический язык,
  // предзаполняется при открытии модалки, психолог может отредактировать.
  function buildClientSummaryDraft(): string {
    return `Привет! Коротко о сегодняшней встрече:\n\n${content.s}\n\nЧто дальше:\n${content.p}`;
  }

  function openSendSummary() {
    setSummaryDraft(buildClientSummaryDraft());
    setSendSummaryError(null);
    setShowSendSummary(true);
  }

  async function handleSendSummary() {
    if (!soapNoteId) {
      setSendSummaryError("Сначала сохраните протокол — без этого его не к чему привязать резюме.");
      return;
    }
    setSendingSummary(true);
    setSendSummaryError(null);
    try {
      const res = await fetch(`/api/soap/${soapNoteId}/send-summary`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ client_summary: summaryDraft, channel: summaryChannel }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSendSummaryError(data.error ?? "Не удалось отправить резюме");
        return;
      }
      if (data.warning) {
        setSendSummaryError(data.warning);
      } else {
        setShowSendSummary(false);
        setNotification("Резюме сохранено и отправлено клиенту");
        setTimeout(() => setNotification(null), 3000);
      }
    } catch {
      setSendSummaryError("Не удалось связаться с сервером — проверьте соединение");
    } finally {
      setSendingSummary(false);
    }
  }

  async function handlePdf() {
    if (!protocolExists) {
      setNotification("Сначала сохраните протокол — без этого нечего экспортировать");
      setTimeout(() => setNotification(null), 3000);
      return;
    }
    setPdfLoading(true);
    try {
      const res = await fetch(`/api/sessions/${sessionId}/soap/pdf`);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setNotification(data.error ?? "Не удалось сформировать PDF");
        setTimeout(() => setNotification(null), 3000);
        return;
      }
      const blob = await res.blob();
      const disposition = res.headers.get("Content-Disposition") ?? "";
      const match = disposition.match(/filename="([^"]+)"/);
      const filename = match?.[1] ?? "protokol.pdf";
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setNotification("Не удалось сформировать PDF — проверьте соединение");
      setTimeout(() => setNotification(null), 3000);
    } finally {
      setPdfLoading(false);
    }
  }

  const selectedTemplate = useMemo(
    () => templates.find(t => t.id === selectedTemplateId) ?? null,
    [templates, selectedTemplateId]
  );

  // Разводим два разных по смыслу вида записей source_type=protocol:
  // форматы записи протокола («… — шаблон протокола») и клинические
  // протоколы вмешательства («Экспозиционная терапия» и т.п.).
  const templateGroups = useMemo(() => {
    const formats = templates.filter(t => /шаблон протокола/i.test(t.title ?? ""));
    const clinical = templates.filter(t => !/шаблон протокола/i.test(t.title ?? ""));
    return { formats, clinical };
  }, [templates]);

  function handleCopy() {
    const fullText = PROTOCOL_BLOCKS.map(b => `${b.label}\n${content[b.key]}`).join("\n\n");
    navigator.clipboard?.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "0 24px" }}>
      {/* Шапка */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        style={{ marginTop: 20, marginBottom: 20 }}
      >
        <Card>
          <CardContent className="pt-6">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <h1 style={{ fontSize: 18, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>
                    Протокол сессии
                  </h1>
                </div>
                <p style={{ fontSize: 13, color: "#6B6058", margin: 0, marginTop: 4 }}>
                  {loading
                    ? "Загрузка…"
                    : sessionInfo
                    ? `${sessionInfo.clientName} · ${new Date(sessionInfo.scheduledAt).toLocaleDateString("ru", { day: "numeric", month: "long", year: "numeric", timeZone })} · ${sessionInfo.durationMinutes} минут`
                    : loadError ?? "Сессия не найдена"}
                </p>
              </div>

              <div style={{ display: "flex", gap: 8 }}>
                <Button onClick={handlePdf} variant="outline" size="sm" disabled={pdfLoading}>
                  <Download size={14} style={{ marginRight: 4 }} />
                  {pdfLoading ? "Готовлю..." : "PDF"}
                </Button>
                <Button onClick={handleSave} variant="primary" size="sm" disabled={saving}>
                  {saved ? <><CheckCircle size={14} style={{ marginRight: 4 }} /> Сохранено</> : saving ? "Сохраняю..." : "Сохранить"}
                </Button>
              </div>
            </div>
            {saveError && (
              <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", marginTop: 12 }}>
                {saveError}
              </p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Выбор формата протокола — подставляет текст шаблона из базы знаний
          (source_type=protocol) как ориентир при ручном заполнении и как
          инструкцию для AI-генерации (см. lib/prompts/soap.ts). Раньше
          шаблоны протоколов существовали в БЗ, но никак не применялись
          к реальной заметке сессии — это тот самый недостающий мостик. */}
      {!loading && templates.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ marginBottom: 20 }}
        >
          <Card>
            <CardContent className="pt-6">
              <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
                Формат протокола
              </label>
              <select
                value={selectedTemplateId}
                onChange={e => setSelectedTemplateId(e.target.value)}
                style={{
                  width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5",
                  borderRadius: 8, fontSize: 13, color: "#1C1C1E", fontFamily: "var(--font-sans)", background: "#FFFFFF",
                }}
              >
                <option value="">Базовый формат (без шаблона)</option>
                {/* В knowledge_base под source_type=protocol лежат две разные
                    по смыслу вещи: форматы записи протокола сессии и
                    терапевтические протоколы вмешательства. В одном плоском
                    списке из 30 позиций психолог не понимал, что выбирает,
                    поэтому разводим их по группам. */}
                {templateGroups.formats.length > 0 && (
                  <optgroup label="Форматы записи протокола">
                    {templateGroups.formats.map(t => (
                      <option key={t.id} value={t.id}>{t.title ?? "Без названия"}</option>
                    ))}
                  </optgroup>
                )}
                {templateGroups.clinical.length > 0 && (
                  <optgroup label="Терапевтические протоколы (структура под интервенцию)">
                    {templateGroups.clinical.map(t => (
                      <option key={t.id} value={t.id}>{t.title ?? "Без названия"}</option>
                    ))}
                  </optgroup>
                )}
              </select>
              {selectedTemplate && (
                <p style={{ fontSize: 12, color: "#6B6058", marginTop: 10, marginBottom: 0, lineHeight: 1.5 }}>
                  {selectedTemplate.content && selectedTemplate.content.length > 260
                    ? `${selectedTemplate.content.slice(0, 260)}…`
                    : selectedTemplate.content}
                </p>
              )}
              <p style={{ fontSize: 11.5, color: "#6F5A3F", marginTop: 8, marginBottom: 0 }}>
                Структура заметки (4 блока ниже) не меняется, но выбранный формат используется как ориентир при генерации по записи сессии и как подсказка при ручном заполнении.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {!loading && !protocolExists && !loadError && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ marginBottom: 24 }}
        >
          <Card>
            <CardContent className="pt-6" style={{ textAlign: "center", padding: "32px 24px" }}>
              <Sparkles size={28} style={{ color: "#6F5A3F", marginBottom: 12 }} />
              <h3 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", margin: "0 0 6px 0" }}>
                Протокол не создан
              </h3>
              <p style={{ fontSize: 13, color: "#6B6058", margin: "0 0 16px 0" }}>
                Для этой сессии ещё нет протокола. Сгенерируйте его автоматически по записи сессии или заполните блоки ниже вручную.
              </p>
              {sessionInfo && recordingStatusHint(sessionInfo.recordingStatus)}
              {generateError && (
                <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", marginBottom: 12 }}>
                  {generateError}
                </p>
              )}
              <Button variant="primary" onClick={handleGenerate} disabled={generating}>
                {generating ? (
                  <><Loader2 size={14} className="animate-spin" style={{ marginRight: 6 }} /> {generateButtonLabel(generateStage)}</>
                ) : (
                  <><Sparkles size={14} style={{ marginRight: 6 }} /> Сгенерировать протокол</>
                )}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {aiGenerated && protocolExists && (
        <div
          role="note"
          style={{
            display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 16, padding: "10px 14px",
            background: "#FEF3C7", border: "1px solid #F59E0B", borderRadius: 10, fontSize: 12.5, color: "#7C5E10", lineHeight: 1.5,
          }}
        >
          <AlertTriangle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
          <div>
            <strong>{AI_DRAFT_NOTICE}</strong>
            {guardReplaced && <div style={{ marginTop: 4 }}>{GUARD_REPLACED_NOTICE}</div>}
          </div>
        </div>
      )}

      {/* Блоки протокола */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16, marginBottom: 24 }}>
        {PROTOCOL_BLOCKS.map((block, idx) => (
          <motion.div
            key={block.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.08 }}
          >
            <Card>
              <CardContent className="pt-6">
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                  <span style={{ fontSize: 20 }}>{block.emoji}</span>
                  <div>
                    <h3 style={{ fontSize: 14, fontWeight: 600, color: "#1C1C1E", margin: 0 }}>
                      {block.label}
                    </h3>
                    <p style={{ fontSize: 11, color: "#6F5A3F", margin: 0, marginTop: 2 }}>
                      {block.hint}
                    </p>
                  </div>
                </div>

                <textarea
                  value={content[block.key]}
                  onChange={e => setContent(prev => ({ ...prev, [block.key]: e.target.value }))}
                  style={{
                    width: "100%",
                    minHeight: 150,
                    padding: "12px 14px",
                    border: `2px solid ${block.color}30`,
                    borderLeft: `4px solid ${block.color}`,
                    borderRadius: 8,
                    fontSize: 13,
                    fontFamily: "var(--font-sans)",
                    color: "#1C1C1E",
                    resize: "none",
                  }}
                />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Генерация контента */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.32 }}
        style={{ marginBottom: 24 }}
      >
        <Card>
          <CardContent className="pt-6">
            <h3 style={{ fontSize: 14, fontWeight: 600, color: "#1C1C1E", marginBottom: 12 }}>
              Действия
            </h3>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {/* Генерация доступна и когда протокол уже существует. Карточка
                  «Протокол не создан» выше показывается только при пустом
                  протоколе, а заметки, написанные прямо во время сессии,
                  сразу сохраняются как протокол — то есть ровно в основном
                  сценарии (психолог набросал тезисы и хочет развернуть их в
                  связный текст) кнопка исчезала и ИИ-генерация по заметкам
                  становилась недостижимой. */}
              {protocolExists && (
                <Button onClick={handleGenerate} variant="secondary" disabled={generating}>
                  {generating ? (
                    <><Loader2 size={14} className="animate-spin" style={{ marginRight: 6 }} /> {generateButtonLabel(generateStage)}</>
                  ) : (
                    <><Sparkles size={14} style={{ marginRight: 6 }} /> Сгенерировать протокол</>
                  )}
                </Button>
              )}
              <Link href={`/content?session=${sessionId}`} style={{ textDecoration: "none" }}>
                <Button variant="primary">
                  <FileOutput size={14} style={{ marginRight: 6 }} /> Сгенерировать контент
                </Button>
              </Link>
              <Button onClick={handleCopy} variant="secondary">
                {copied ? <><CheckCircle size={14} style={{ marginRight: 6 }} /> Скопировано</> : <><Copy size={14} style={{ marginRight: 6 }} /> Копировать</>}
              </Button>
              <Button onClick={handleDownloadTranscript} variant="secondary" disabled={downloadingTranscript}>
                <Download size={14} style={{ marginRight: 6 }} />
                {downloadingTranscript ? "Скачиваю..." : "Скачать транскрипт"}
              </Button>
              <Button onClick={() => setShowUploadTranscript(true)} variant="secondary">
                <FileOutput size={14} style={{ marginRight: 6 }} /> Загрузить транскрипт
              </Button>
              <Button onClick={openSendSummary} variant="secondary">
                <Send size={14} style={{ marginRight: 6 }} /> Отправить резюме клиенту
              </Button>
            </div>
            {/* Ошибку генерации показываем и здесь: карточка «Протокол не
                создан», где она выводилась раньше, при заполненном протоколе
                скрыта — иначе неудачная генерация выглядела бы как полное
                отсутствие реакции на нажатие. */}
            {protocolExists && generateError && (
              <p style={{ fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px", marginTop: 12, marginBottom: 0 }}>
                {generateError}
              </p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {notification && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            position: "fixed", top: 24, left: "50%", transform: "translateX(-50%)",
            background: "#157347", color: "#fff", padding: "12px 20px",
            borderRadius: 8, fontSize: 13, fontWeight: 600, zIndex: 60,
            boxShadow: "0 4px 12px rgba(27, 175, 122, 0.3)",
          }}
        >
          {notification}
        </motion.div>
      )}

      {/* Модалка ручной загрузки транскрипта — вставить текст или выбрать
          .txt-файл. Для сессий, проведённых не через видеозвонок
          платформы, или когда автоматическая расшифровка не удалась. */}
      {showUploadTranscript && (
        <>
          <div
            onClick={() => !uploadingTranscript && setShowUploadTranscript(false)}
            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 70 }}
          />
          <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 75,
          }}>
            <div style={{
              background: "#fff", borderRadius: 16, padding: 24, width: "min(560px, 92vw)",
              maxHeight: "85vh", display: "flex", flexDirection: "column", gap: 12,
            }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1C1C1E" }}>Загрузить транскрипт вручную</h3>
                <button
                  onClick={() => !uploadingTranscript && setShowUploadTranscript(false)}
                  style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: "#6F5A3F" }}
                >
                  <X size={18} />
                </button>
              </div>
              <p style={{ margin: 0, fontSize: 12.5, color: "#6F5A3F" }}>
                Подходит, если сессия прошла не через видеозвонок платформы, или автоматическая
                расшифровка не удалась. Текст сохранится в историю клиента так же, как обычный
                транскрипт — им сможет пользоваться ассистент и генерация протокола.
              </p>
              <label style={{ fontSize: 12.5, fontWeight: 600, color: "#4A3F35" }}>
                Загрузить .txt-файл
                <input
                  type="file"
                  accept=".txt,text/plain"
                  onChange={handleTranscriptFileChange}
                  style={{ display: "block", marginTop: 6, fontSize: 12.5 }}
                />
              </label>
              <p style={{ margin: "0", fontSize: 11.5, color: "#6F5A3F", textAlign: "center" }}>— или вставьте текст ниже —</p>
              <textarea
                value={uploadTranscriptText}
                onChange={e => { setUploadTranscriptText(e.target.value); setUploadTranscriptError(null); }}
                placeholder="Вставьте текст транскрипта сессии…"
                rows={10}
                style={{
                  width: "100%", resize: "vertical", padding: 10, borderRadius: 8,
                  border: "1px solid #E5DFD5", fontSize: 13, fontFamily: "inherit",
                  color: "#1C1C1E", background: "#fff",
                }}
              />
              {uploadTranscriptText && (
                <p style={{ margin: 0, fontSize: 11.5, color: "#6F5A3F" }}>
                  {uploadTranscriptText.length.toLocaleString("ru-RU")} символов
                </p>
              )}
              {uploadTranscriptError && (
                <p style={{ margin: 0, fontSize: 12.5, color: "#B91C1C", background: "#FEE2E2", borderRadius: 8, padding: "8px 12px" }}>
                  {uploadTranscriptError}
                </p>
              )}
              <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                <Button variant="secondary" onClick={() => setShowUploadTranscript(false)} disabled={uploadingTranscript}>
                  Отмена
                </Button>
                <Button onClick={handleUploadTranscript} disabled={uploadingTranscript || !uploadTranscriptText.trim()}>
                  {uploadingTranscript ? "Загружаю…" : "Сохранить транскрипт"}
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Модалка отправки резюме клиенту */}
      {showSendSummary && (
        <>
          <div
            onClick={() => !sendingSummary && setShowSendSummary(false)}
            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 70 }}
          />
          <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 75,
          }}>
            <div style={{
              background: "#FFFFFF", borderRadius: 16, width: "90%", maxWidth: 480,
              maxHeight: "85vh", overflowY: "auto", boxShadow: "0 25px 80px rgba(0,0,0,0.2)",
            }}>
              <div style={{
                padding: "18px 22px", borderBottom: "1px solid #E5DFD5",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <h2 style={{ fontSize: 15, fontWeight: 700, color: "#1C1C1E", margin: 0 }}>
                  Отправить резюме клиенту
                </h2>
                <button
                  onClick={() => !sendingSummary && setShowSendSummary(false)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#6F5A3F" }}
                >
                  <X size={18} />
                </button>
              </div>

              <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                    Текст резюме (можно отредактировать)
                  </label>
                  <textarea
                    value={summaryDraft}
                    onChange={e => setSummaryDraft(e.target.value)}
                    style={{
                      width: "100%", minHeight: 160, padding: "10px 12px",
                      border: "1px solid #E5DFD5", borderRadius: 8,
                      fontSize: 13, fontFamily: "var(--font-sans)", color: "#1C1C1E", resize: "vertical",
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: "#6F5A3F", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                    Канал отправки
                  </label>
                  <select
                    value={summaryChannel}
                    onChange={e => setSummaryChannel(e.target.value as "telegram" | "vk" | "max")}
                    style={{
                      width: "100%", padding: "9px 12px", border: "1px solid #E5DFD5",
                      borderRadius: 8, fontSize: 13, color: "#1C1C1E", fontFamily: "var(--font-sans)", background: "#FFFFFF",
                    }}
                  >
                    <option value="telegram">Telegram</option>
                    <option value="vk">VK</option>
                    <option value="max">MAX</option>
                  </select>
                </div>

                {sendSummaryError && (
                  <p style={{ fontSize: 12.5, color: "#92400E", background: "#FEF3E2", borderRadius: 8, padding: "10px 12px", margin: 0 }}>
                    {sendSummaryError}
                  </p>
                )}

                <Button onClick={handleSendSummary} variant="primary" disabled={sendingSummary}>
                  {sendingSummary ? "Отправляю..." : "Отправить"}
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
